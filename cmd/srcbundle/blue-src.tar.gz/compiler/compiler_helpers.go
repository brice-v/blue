package compiler

import (
	"blue/ast"
	"blue/code"
	"blue/consts"
	"blue/lexer"
	"blue/object"
	"blue/parser"
	"blue/token"
	"bytes"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
)

func (c *Compiler) compileInfixExpression(operator string) error {
	switch operator {
	case "+":
		c.emit(code.OpAdd)
	case "-":
		c.emit(code.OpMinus)
	case "*":
		c.emit(code.OpStar)
	case "**":
		c.emit(code.OpPow)
	case "/":
		c.emit(code.OpDiv)
	case "//":
		c.emit(code.OpFlDiv)
	case "%":
		c.emit(code.OpPercent)
	case "^":
		c.emit(code.OpCarat)
	case "&":
		c.emit(code.OpAmpersand)
	case "|":
		c.emit(code.OpPipe)
	case "in":
		c.emit(code.OpIn)
	case "notin":
		c.emit(code.OpNotin)
	case "..":
		c.emit(code.OpRange)
	case "..<":
		c.emit(code.OpNonIncRange)
	case ">>":
		c.emit(code.OpRshift)
	case "<<":
		c.emit(code.OpLshift)
	case "==":
		c.emit(code.OpEqual)
	case "!=":
		c.emit(code.OpNotEqual)
	case "||", "or":
		c.emit(code.OpOr)
	case "&&", "and":
		c.emit(code.OpAnd)
	case ">=", "<=":
		c.emit(code.OpGreaterThanOrEqual)
	case ">", "<":
		c.emit(code.OpGreaterThan)
	default:
		return fmt.Errorf("unsupported operator: %s", operator)
	}
	return nil
}

func (c *Compiler) compileIfExpression(node *ast.IfExpression) error {
	allEndingJumpPos := []int{}
	for i := range node.Conditions {
		err := c.Compile(node.Conditions[i])
		if err != nil {
			return err
		}
		// Emit an `OpJumpNotTruthy` with a bogus value
		jumpNotTruthyPos := c.emit(code.OpJumpNotTruthy, 9999)
		err = c.Compile(node.Consequences[i])
		if err != nil {
			return err
		}
		if c.lastInstructionIsSet() {
			c.emit(code.OpNull)
		}
		if c.lastInstructionIs(code.OpPop) {
			c.removeLastPop()
		}
		// Emit an `OpJump` with a bogus value
		jumpPos := c.emit(code.OpJump, 9999)
		allEndingJumpPos = append(allEndingJumpPos, jumpPos)
		afterConsequencePos := len(c.currentInstructions())
		c.changeOperand(jumpNotTruthyPos, afterConsequencePos)
	}
	if node.Alternative == nil {
		c.emit(code.OpNull)
	} else {
		err := c.Compile(node.Alternative)
		if err != nil {
			return err
		}
		if c.lastInstructionIsSet() {
			c.emit(code.OpNull)
		}
		if c.lastInstructionIs(code.OpPop) {
			c.removeLastPop()
		}
	}
	afterAlternativePos := len(c.currentInstructions())
	for _, jumpPos := range allEndingJumpPos {
		c.changeOperand(jumpPos, afterAlternativePos)
	}
	return nil
}

func (c *Compiler) enterBlock() {
	c.symbolTable.BlockNestLevel++
}

func (c *Compiler) exitBlock() {
	prefix := fmt.Sprintf("%d:", c.symbolTable.BlockNestLevel)
	for k := range c.symbolTable.store {
		if strings.HasPrefix(k, prefix) {
			delete(c.symbolTable.store, k)
		}
	}
	c.symbolTable.BlockNestLevel--
}

func (c *Compiler) loadSymbol(s Symbol) {
	if s.Scope == SpecialFunctionScope {
		c.emit(code.OpGetFunctionParameterSpecial, s.BuiltinModuleIndex, s.Index)
		return
	}
	if s.Immutable {
		switch s.Scope {
		case GlobalScope:
			c.emit(code.OpGetGlobalImm, s.Index)
		case LocalScope:
			c.emit(code.OpGetLocalImm, s.Index)
		case BuiltinScope:
			c.emit(code.OpGetBuiltin, s.BuiltinModuleIndex, s.Index)
		case FreeScope:
			c.emit(code.OpGetFreeImm, s.Index)
		}
	} else {
		switch s.Scope {
		case GlobalScope:
			c.emit(code.OpGetGlobal, s.Index)
		case LocalScope:
			c.emit(code.OpGetLocal, s.Index)
		case BuiltinScope:
			c.emit(code.OpGetBuiltin, s.BuiltinModuleIndex, s.Index)
		case FreeScope:
			c.emit(code.OpGetFree, s.Index)
		}
	}
}

func (c *Compiler) compileAssignmentExpression(node *ast.AssignmentExpression) error {
	if ident, ok := node.Left.(*ast.Identifier); ok {
		return c.compileAssignmentWithIdent(ident, node.Token.Literal, node.Value)
	} else if indexExp, ok := node.Left.(*ast.IndexExpression); ok {
		return c.compileAssignmentWithIndex(indexExp, node.Token.Literal, node.Value)
	}
	return fmt.Errorf("left side type not supported for assignment expression: %T", node.Left)
}

func (c *Compiler) compileAssignmentWithIdent(ident *ast.Identifier, operator string, v ast.Expression) error {
	// TODO: Look into why this is necessary (happens with for ident in iterable in imported file)
	// Resolve without the module qualifier first so that a local (such as a
	// parameter with a default value) takes precedence over a module level
	// symbol that happens to share its name
	unqualifiedSym, unqualifiedOk := c.symbolTable.Resolve(ident.Value)
	sym := unqualifiedSym
	if !unqualifiedOk || unqualifiedSym.Scope != LocalScope {
		qualifiedSym, qualifiedOk := c.symbolTable.Resolve(c.getName(ident.Value))
		if qualifiedOk {
			sym = qualifiedSym
		} else if !unqualifiedOk {
			return fmt.Errorf("identifier not found: %s", ident.Value)
		}
		// else: fall back to the unqualified symbol to resolve local
		// variables from imported files
	}
	if sym.Immutable {
		return fmt.Errorf("'%s' is immutable", ident.Value)
	}
	// If its not assignment then compile as if this is an infix expression
	if operator != "=" {
		// Compile "get" for the variable being assigned to
		c.loadSymbol(sym)
		// Always compile right hand side value first
		err := c.Compile(v)
		if err != nil {
			return err
		}
		op, ok := assignmentToInfixOperator[operator]
		if !ok {
			return fmt.Errorf("invalid assignment operator: %s", operator)
		}
		err = c.compileInfixExpression(op)
		if err != nil {
			return err
		}
	} else {
		err := c.Compile(v)
		if err != nil {
			return err
		}
	}
	if sym.Scope == GlobalScope {
		c.emit(code.OpSetGlobal, sym.Index)
	} else {
		c.emit(code.OpSetLocal, sym.Index)
	}
	return nil
}

var assignmentToInfixOperator = map[string]string{
	"+=":  "+",
	"-=":  "-",
	"*=":  "*",
	"/=":  "/",
	"//=": "//",
	"**=": "**",
	"&=":  "&",
	"|=":  "|",
	"<<=": "<<",
	">>=": ">>",
	"%=":  "%",
	"^=":  "^",
	"&&=": "&&",
	"||=": "||",
}

func (c *Compiler) compileAssignmentWithIndex(index *ast.IndexExpression, operator string, v ast.Expression) error {
	rootIdent, ok := getRootIdent(index)
	if !ok {
		return fmt.Errorf("could not find identifier for assignmenet")
	}
	var sym Symbol
	// Resolve without the module qualifier first so that a local (such as a
	// parameter with a default value) takes precedence over a module level
	// symbol that happens to share its name
	unqualifiedSym, unqualifiedOk := c.symbolTable.Resolve(rootIdent.Value)
	sym = unqualifiedSym
	if !unqualifiedOk || unqualifiedSym.Scope != LocalScope {
		qualifiedSym, qualifiedOk := c.symbolTable.Resolve(c.getName(rootIdent.Value))
		if qualifiedOk {
			sym = qualifiedSym
		} else if !unqualifiedOk {
			return fmt.Errorf("identifier not found: %s", rootIdent.Value)
		}
		// else: fall back to the unqualified symbol to resolve local
		// variables from imported files
	}
	if sym.Immutable {
		return fmt.Errorf("'%s' is immutable", rootIdent.Value)
	}
	if operator != "=" {
		err := c.Compile(index)
		if err != nil {
			return err
		}
		err = c.Compile(v)
		if err != nil {
			return err
		}
		op, ok := assignmentToInfixOperator[operator]
		if !ok {
			return fmt.Errorf("invalid assignment operator: %s", operator)
		}
		err = c.compileInfixExpression(op)
		if err != nil {
			return err
		}
	} else {
		err := c.Compile(v)
		if err != nil {
			return err
		}
	}
	err := c.Compile(index)
	if err != nil {
		return err
	}
	if c.lastInstructionIs(code.OpIndex) {
		c.removeLastInstruction()
	}
	c.emit(code.OpIndexSet)
	return nil
}

func getRootIdent(node *ast.IndexExpression) (*ast.Identifier, bool) {
	left := node.Left
	for {
		if ident, ok := left.(*ast.Identifier); ok {
			left = ident
			break
		} else if indx, ok := left.(*ast.IndexExpression); ok {
			left = indx.Left
		} else {
			return nil, false
		}
	}
	ident, ok := left.(*ast.Identifier)
	if !ok {
		return nil, false
	}
	return ident, ok
}

func (c *Compiler) compileForStatement(node *ast.ForStatement) error {
	c.forIndex++
	if node.UsesVar {
		err := c.Compile(node.Initializer)
		if err != nil {
			return err
		}
	} else {
		ok, sym, right := c.isIdentOnLeftInIterableOnRight(node.Condition)
		if ok {
			err := c.compileIdentInIterableFor(sym, node, right)
			if err != nil {
				return err
			}
		} else {
			ok, sym1, sym2, right := c.isListIdentsOnLeftInIterableOnRight(node.Condition)
			if ok {
				err := c.compileListIdentsInIterableFor(sym1, sym2, node, right)
				if err != nil {
					return err
				}
			}
		}
	}
	condPos := len(c.currentInstructions())
	err := c.Compile(node.Condition)
	if err != nil {
		return err
	}
	// Emit an `OpJumpNotTruthy` with a bogus value
	jumpNotTruthyPos := c.emit(code.OpJumpNotTruthy, 9999)
	for _, setter := range node.IterableSetters {
		err := c.Compile(setter)
		if err != nil {
			return err
		}
	}
	err = c.Compile(node.Consequence)
	if err != nil {
		return err
	}
	postExpPos := -1
	if node.PostExp != nil {
		postExpPos = len(c.currentInstructions())
		err = c.Compile(node.PostExp)
		if err != nil {
			return err
		}
	}
	// NOTE: unlike if/match expressions, a for statement is never used as an
	// expression, so the body's trailing value must be popped every
	// iteration. Stripping this OpPop leaked one stack slot per iteration
	// until long lived loops exhausted the vm stack.
	if c.lastInstructionIs(code.OpNull) {
		c.removeLastInstruction()
	}
	c.emit(code.OpJump, condPos)
	afterConsequencePos := len(c.currentInstructions())
	c.changeOperand(jumpNotTruthyPos, afterConsequencePos)
	if breakPoss, ok := c.breakPos[c.forIndex]; ok {
		for _, pos := range breakPoss {
			c.changeOperand(pos, afterConsequencePos)
		}
	}
	if contPoss, ok := c.contPos[c.forIndex]; ok {
		for _, pos := range contPoss {
			if node.PostExp != nil {
				c.changeOperand(pos, postExpPos)
			} else {
				c.changeOperand(pos, condPos)
			}
		}
	}
	delete(c.breakPos, c.forIndex)
	delete(c.contPos, c.forIndex)
	c.forIndex--
	return nil
}

func (c *Compiler) getName(name string) string {
	if c.importNestLevel == -1 {
		return name
	}
	return fmt.Sprintf("%s.%s", c.modName[c.importNestLevel], name)
}

func (c *Compiler) createFilePathFromImportPath(importPath string) string {
	var fpath bytes.Buffer
	if c.CompilerBasePath != "." {
		fpath.WriteString(c.CompilerBasePath)
		fpath.WriteString(string(os.PathSeparator))
	}
	importPath = strings.ReplaceAll(importPath, ".", string(os.PathSeparator))
	fpath.WriteString(importPath)
	fpath.WriteString(".b")
	return fpath.String()
}

func (c *Compiler) compileImportStatement(node *ast.ImportStatement) error {
	name := node.Path.Value
	if IsStd(name) {
		if node.Alias != nil {
			return fmt.Errorf("alias for std module not supported")
		}
		return c.CompileStdModule(name, node.IdentsToImport, node.ImportAll)
	}
	fpath := c.createFilePathFromImportPath(name)
	modName := strings.ReplaceAll(filepath.Base(fpath), ".b", "")
	var inputStr string
	if !object.IsEmbed {
		file, err := filepath.Abs(fpath)
		if err != nil {
			return fmt.Errorf("failed to import '%s'. Could not get absolute filepath", name)
		}
		ofile, err := os.Open(file)
		if err != nil {
			return fmt.Errorf("failed to import '%s'. Could not open file '%s' for reading", name, file)
		}
		defer func() {
			err := ofile.Close()
			if err != nil {
				log.Printf("Failed to close embed file %s, error: %s", fpath, err.Error())
			}
		}()
		fileData, err := io.ReadAll(ofile)
		if err != nil {
			return fmt.Errorf("failed to import '%s'. Could not read the file", name)
		}
		inputStr = string(fileData)
		c.ReadFiles = append(c.ReadFiles, file)
	} else {
		fileData, err := object.Files.ReadFile(consts.EMBED_FILES_PREFIX + fpath)
		if err != nil {
			return fmt.Errorf("failed to import '%s'. Could not read the file at path '%s'", name, fpath)
		}
		inputStr = string(fileData)
	}

	l := lexer.New(inputStr, fpath)
	p := parser.New(l)
	program := p.ParseProgram()
	if p.HasErrors() {
		p.PrintParserErrors(os.Stderr)
		return fmt.Errorf("%sFile '%s' contains Parser Errors", consts.PARSER_ERROR_PREFIX, name)
	}
	if node.ImportAll {
		// Import All acts as if everything is in the current file
		return c.Compile(program)
	}
	checkNodeIdentsToImport := len(node.IdentsToImport) > 0
	if checkNodeIdentsToImport {
		for _, ident := range node.IdentsToImport {
			if strings.HasPrefix(ident.Value, "_") {
				return fmt.Errorf("imports must be public to import them. failed to import %s from %s", ident.Value, modName)
			}
		}
		// TODO: Add test case trying to call method such as abc._hello() => this should ideally fail to compile
		// when called from the file importing abc
	}
	if node.Alias != nil {
		modName = node.Alias.Value
	}
	c.importNestLevel++
	c.modName = append(c.modName, modName)
	err := c.Compile(program)
	if err != nil {
		return err
	}
	if checkNodeIdentsToImport {
		for _, ident := range node.IdentsToImport {
			err := c.symbolTable.UpdateName(fmt.Sprintf("%s.%s", name, ident.Value), ident.Value)
			if err != nil {
				return err
			}
		}
	}
	c.modName = c.modName[:c.importNestLevel]
	c.importNestLevel--
	c.ValidModuleNames = append(c.ValidModuleNames, modName)
	// So the problem now is that index operator, needs to work based off available modules
	// while compiling, if we encounter a identifier that is a module, we must pull it in
	pubFunHelpStr := c.symbolTable.GetOrderedPublicFunctionHelpString(modName)
	literal := &object.Module{Name: modName, Env: nil, HelpStr: object.CreateHelpStringFromProgramTokens(modName, program.HelpStrTokens, pubFunHelpStr)}
	c.emit(code.OpConstant, c.addConstant(literal))
	symbol := c.symbolTable.Define(modName, true)
	switch symbol.Scope {
	case GlobalScope:
		c.emit(code.OpSetGlobalImm, symbol.Index)
	case LocalScope:
		c.emit(code.OpSetLocalImm, symbol.Index)
	}
	return nil
}

func (c *Compiler) compileIndexExpression(node *ast.IndexExpression) error {
	c.emitNode(node)
	if infixExpr, isInfix := node.Index.(*ast.InfixExpression); isInfix {
		if infixExpr.Operator == ".." || infixExpr.Operator == "..<" {
			return c.compileSliceExpression(node)
		}
	}
	leftIdent, leftIsIdent := node.Left.(*ast.Identifier)
	rightStr, rightIsStr := node.Index.(*ast.StringLiteral)
	if leftIsIdent && rightIsStr {
		// Check if left is a module and if together this can be resolved
		if sym, ok := c.symbolTable.Resolve(fmt.Sprintf("%s.%s", leftIdent.Value, rightStr.Value)); ok {
			c.loadSymbol(sym)
			return nil
		}
	}
	isDotCall := node.Token.Literal == "."
	// Support uniform function call syntax "".println()
	var symbolToIndex *Symbol = nil
	useSpecialIndexHelper := false
	if rightIsStr {
		if sym, ok := c.symbolTable.Resolve(c.getName(rightStr.Value)); ok {
			// Allow enclosing function to use 'str' version of index var instead of
			// what it would resolve to in parent/higher scope
			// e.g. var m = {}; var a = 1; m['a'] = a; fun() { m.a + 1 }
			// Here, m.a would refer to the map's version of 'a', and not the value 1.
			if isDotCall && sym.Scope != FreeScope {
				symbolToIndex = &sym
				useSpecialIndexHelper = sym.Scope == GlobalScope || sym.Scope == BuiltinScope
			}
		} else if sym, ok1 := c.symbolTable.Resolve(rightStr.Value); ok1 {
			// When inside a module, we still want to be able to resolve dot calls
			// using builtin functions
			if isDotCall && (sym.Scope == BuiltinScope || sym.Scope == GlobalScope) {
				symbolToIndex = &sym
				useSpecialIndexHelper = sym.Scope == GlobalScope || sym.Scope == BuiltinScope
			}
		}
	}

	err := c.Compile(node.Left)
	if err != nil {
		return err
	}
	if useSpecialIndexHelper {
		c.emit(code.OpConstant, c.addConstant(&object.Stringo{Value: node.Index.(*ast.StringLiteral).Value}))
		posToChange := c.emit(code.OpSpecialIndexHelper, 9999)
		c.loadSymbolOrSpecialCaseForProcess(*symbolToIndex)
		c.changeOperand(posToChange, len(c.currentInstructions()))
	} else {
		if symbolToIndex == nil {
			err = c.Compile(node.Index)
			if err != nil {
				return err
			}
		} else {
			c.loadSymbolOrSpecialCaseForProcess(*symbolToIndex)
		}
	}
	c.emit(code.OpIndex)
	return nil
}

func (c *Compiler) loadSymbolOrSpecialCaseForProcess(s Symbol) {
	if s.Immutable && s.Scope == GlobalScope {
		processKeyIndex := object.GetProcessKeyIndex(s.Name)
		if processKeyIndex != 0 {
			c.emit(code.OpGetGlobalImmOrSpecial, s.Index, int(processKeyIndex))
			return
		}
	}
	c.loadSymbol(s)
}

func (c *Compiler) compileSliceExpression(node *ast.IndexExpression) error {
	err := c.Compile(node.Left)
	if err != nil {
		return err
	}
	err = c.Compile(node.Index)
	if err != nil {
		return err
	}
	c.emit(code.OpSlice)
	return nil
}

func (c *Compiler) compileCompLiteral(t, nonEvaluatedProgram string) error {
	symName := fmt.Sprintf("__internal__%d", c.listSetMapCompLiteralIndex)
	c.listSetMapCompLiteralIndex++
	s := strings.ReplaceAll(nonEvaluatedProgram, "__internal__", symName)
	l := lexer.New(s, fmt.Sprintf("<internal:%s>", t))
	p := parser.New(l)
	rootNode := p.ParseProgram()
	if len(rootNode.Statements) < 1 {
		return fmt.Errorf("%s error:, not enough statements", t)
	}
	if p.HasErrors() {
		return fmt.Errorf("%s error: %s", t, p.JoinedErrors())
	}
	// Comprehensions are self contained programs so '_' inside of them must not
	// be treated as a match wildcard even if we are currently compiling a match condition
	prevInMatch := c.inMatch
	c.inMatch = false
	err := c.Compile(rootNode)
	c.inMatch = prevInMatch
	if err != nil {
		return err
	}
	sym, ok := c.symbolTable.Resolve(symName)
	if !ok {
		return fmt.Errorf("this should never occur, failed to resolve: %s", symName)
	}
	c.loadSymbol(sym)
	return nil
}

func (c *Compiler) compileListCompLiteral(node *ast.ListCompLiteral) error {
	err := c.compileCompLiteral("ListCompLiteral", node.NonEvaluatedProgram)
	if err != nil {
		return err
	}
	c.emit(code.OpListCompLiteral)
	return nil
}

func (c *Compiler) compileSetCompLiteral(node *ast.SetCompLiteral) error {
	err := c.compileCompLiteral("SetCompLiteral", node.NonEvaluatedProgram)
	if err != nil {
		return err
	}
	c.emit(code.OpSetCompLiteral)
	return nil
}

func (c *Compiler) compileMapCompLiteral(node *ast.MapCompLiteral) error {
	err := c.compileCompLiteral("MapCompLiteral", node.NonEvaluatedProgram)
	if err != nil {
		return err
	}
	c.emit(code.OpMapCompLiteral)
	return nil
}

func (c *Compiler) compileMatchExpression(node *ast.MatchExpression) error {
	if c.inMatch {
		return fmt.Errorf("cannot nest a match expression inside of another match expression's condition\n%s", lexer.GetErrorLineMessage(node.Token))
	}
	conditionLen := len(node.Conditions)
	consequenceLen := len(node.Consequences)
	if conditionLen != consequenceLen {
		return fmt.Errorf("conditions length is not equal to consequences length in match expression")
	}
	allEndingJumpPos := []int{}
	for i := range node.Conditions {
		var err error
		var jumpNotTruthyPos int
		for j := range node.Conditions[i] {
			condIsDefault := node.Conditions[i][j].String() == "_"
			if !condIsDefault {
				// Save/restore around the condition so that an error partway through
				// compiling it cannot leave the compiler stuck in 'match' context
				prevInMatch := c.inMatch
				c.inMatch = true
				err = c.Compile(node.Conditions[i][j])
				c.inMatch = prevInMatch
				if err != nil {
					return err
				}
				if node.OptionalValue != nil && !c.lastInstructionReturnsBool() {
					err = c.Compile(node.OptionalValue)
					if err != nil {
						return err
					}
					c.emit(code.OpMatchValue)
				}
				jumpNotTruthyPos = c.emit(code.OpJumpNotTruthy, 9999)
			}
			err = c.Compile(node.Consequences[i])
			if err != nil {
				return err
			}
			if c.lastInstructionIsSet() {
				c.emit(code.OpNull)
			}
			if c.lastInstructionIs(code.OpPop) {
				c.removeLastPop()
			}
			jumpPos := c.emit(code.OpJump, 9999)
			allEndingJumpPos = append(allEndingJumpPos, jumpPos)
			afterConsequencePos := len(c.currentInstructions())
			if !condIsDefault {
				c.changeOperand(jumpNotTruthyPos, afterConsequencePos)
			}
		}
	}
	afterAlternativePos := len(c.currentInstructions())
	for _, jumpPos := range allEndingJumpPos {
		c.changeOperand(jumpPos, afterAlternativePos)
	}
	return nil
}

var _ignore_str = &ast.StringLiteral{Value: object.USE_PARAM_STR}

func (c *Compiler) setupFunction(parameters []*ast.Identifier, parameterExpressions []ast.Expression, body *ast.BlockStatement, astStr string) *object.CompiledFunction {
	specialFunctionParameters := c.setupFunctionParameters(parameters, parameterExpressions)
	compiledFun := &object.CompiledFunction{
		Parameters:          make([]string, len(parameters)),
		ParameterHasDefault: make([]bool, len(parameters)),
		NumParameters:       len(parameters),
		DisplayString:       astStr,

		SpecialFunctionParameters: specialFunctionParameters,
	}
	defaultParams := 0
	var statementsToPrepend []ast.Statement = nil
	for i, param := range parameterExpressions {
		compiledFun.Parameters[i] = parameters[i].Value
		if param != nil {
			defaultParams++
			compiledFun.ParameterHasDefault[i] = true
			compiledFun.NumDefaultParams++
			paramIdent := parameters[i]
			paramIsProvidedExpr := &ast.InfixExpression{Operator: "==", Left: paramIdent, Right: _ignore_str}
			assignmentExpr := &ast.AssignmentExpression{Token: token.Token{Type: token.EQ, Literal: "="}, Left: paramIdent, Value: param}
			ifExpr := &ast.IfExpression{
				Conditions:   []ast.Expression{paramIsProvidedExpr},
				Consequences: []*ast.BlockStatement{{Statements: []ast.Statement{&ast.ExpressionStatement{Expression: assignmentExpr}}}},
			}
			ifExprStatement := &ast.ExpressionStatement{Expression: ifExpr}
			if statementsToPrepend == nil {
				statementsToPrepend = []ast.Statement{}
			}
			statementsToPrepend = append([]ast.Statement{ifExprStatement}, statementsToPrepend...)

		} else {
			compiledFun.ParameterHasDefault[i] = false
		}
	}
	if statementsToPrepend != nil {
		body.Statements = append(statementsToPrepend, body.Statements...)
	}
	return compiledFun
}

func (c *Compiler) setupFunctionParameters(parameters []*ast.Identifier, parameterExpressions []ast.Expression) map[object.NameIndexKey]map[object.NameIndexKey]object.Object {
	var specialFunctionParameters map[object.NameIndexKey]map[object.NameIndexKey]object.Object = nil
	lensEqual := len(parameters) == len(parameterExpressions)
	for i, p := range parameters {
		c.symbolTable.Define(p.Value, false)
		if !lensEqual {
			continue
		}
		defaultExpression := parameterExpressions[i]
		if defaultExpression != nil {
			if l, ok := defaultExpression.(*ast.ListLiteral); ok {
				allStr := true
				for _, elem := range l.Elements {
					_, isStr := elem.(*ast.StringLiteral)
					allStr = allStr && isStr
				}
				if !allStr {
					continue
				}
				if specialFunctionParameters == nil {
					specialFunctionParameters = make(map[object.NameIndexKey]map[object.NameIndexKey]object.Object)
				}
				key := object.NameIndexKey{Name: p.Value, Index: i}
				if _, ok := specialFunctionParameters[key]; !ok {
					specialFunctionParameters[key] = make(map[object.NameIndexKey]object.Object)
				}
				for ii, elem := range l.Elements {
					s := elem.(*ast.StringLiteral).Value
					c.symbolTable.defineSpecial(s, c.scopeIndex, i, ii)
					specialFunctionParameters[key][object.NameIndexKey{Name: s, Index: ii}] = nil
				}
			}
		}
	}
	return specialFunctionParameters
}

func (c *Compiler) compileCallExpression(node *ast.CallExpression) error {
	err := c.Compile(node.Function)
	if err != nil {
		return c.addNodeToErrorTrace(err, node.Token)
	}
	for _, arg := range node.Arguments {
		err := c.Compile(arg)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	}
	if len(node.DefaultArguments) != 0 {
		for k, v := range node.DefaultArguments {
			err = c.Compile(&ast.StringLiteral{Value: k})
			if err != nil {
				return c.addNodeToErrorTrace(err, v.TokenToken())
			}
			err = c.Compile(v)
			if err != nil {
				return c.addNodeToErrorTrace(err, v.TokenToken())
			}
		}
		c.emit(code.OpDefaultArgs, len(node.DefaultArguments)*2)
	}
	argLen := len(node.Arguments)
	if len(node.DefaultArguments) != 0 {
		argLen++
	}
	c.emitNode(node)
	c.emit(code.OpCall, argLen)
	return nil
}

func (c *Compiler) compileVarValStatements(node ast.VarValStatement) error {
	err := c.Compile(node.VVValue())
	if err != nil {
		return c.addNodeToErrorTrace(err, node.VVToken())
	}
	names := node.VVNames()
	if len(names) > 255 {
		return c.addNodeToErrorTrace(fmt.Errorf("destructor does not support more than 255 names"), node.VVToken())
	}
	for keyName, newName := range node.VVKeyValueNames() {
		var key string
		if ss, ok := keyName.(*ast.StringLiteral); ok {
			key = ss.Value
		} else if ss, ok := keyName.(*ast.Identifier); ok {
			key = ss.Value
		}
		if c.importNestLevel == -1 {
			if existing, ok := c.symbolTable.LookupInCurrentBlockLevel(c.getName(newName.Value)); ok && (existing.Scope == GlobalScope || existing.Scope == LocalScope) {
				return c.addNodeToErrorTrace(fmt.Errorf("'%s' is already defined in current scope", newName.Value), node.VVToken())
			}
		}
		c.emit(code.OpConstant, c.addConstant(&object.Stringo{Value: key}))
		c.emit(code.OpGetMapKey)
		symbol, immutable := c.defineSymbolForVarValStatement(node, newName.Value)
		c.emitSetSymbolOpcode(symbol, immutable)
		c.emit(code.OpPop)
	}
	for i, name := range names {
		if c.importNestLevel == -1 {
			if existing, ok := c.symbolTable.LookupInCurrentBlockLevel(c.getName(name.Value)); ok && (existing.Scope == GlobalScope || existing.Scope == LocalScope) {
				return c.addNodeToErrorTrace(fmt.Errorf("'%s' is already defined in current scope", name.Value), node.VVToken())
			}
		}
		if node.VVIsListDestructor() {
			c.emit(code.OpGetListIndex, i)
		} else if node.VVIsMapDestructor() {
			c.emit(code.OpConstant, c.addConstant(&object.Stringo{Value: name.Value}))
			c.emit(code.OpGetMapKey)
		}
		symbol, immutable := c.defineSymbolForVarValStatement(node, name.Value)
		c.emitSetSymbolOpcode(symbol, immutable)
		if node.VVIsMapDestructor() {
			c.emit(code.OpPop)
		}
	}
	return nil
}

func (c *Compiler) defineSymbolForVarValStatement(node ast.VarValStatement, name string) (Symbol, bool) {
	var symbol Symbol
	immutable := node.IsValStatement()
	if fun, isFun := node.VVValue().(*ast.FunctionLiteral); isFun {
		helpStr := createHelpStringFromAstFunction(name, fun.String(), fun.Body.HelpStrTokens)
		symbol = c.symbolTable.DefineFun(c.getName(name), immutable, fun.Parameters, fun.ParameterExpressions, helpStr)
	} else {
		symbol = c.symbolTable.Define(c.getName(name), immutable)
	}
	return symbol, immutable
}

// createHelpStringFromAstFunction builds the doc/help string for a function
// from its AST node. It used to live in package object but only the
// compiler consumes it, and object must stay free of ast dependencies.
func createHelpStringFromAstFunction(functionName string, funObjString string, helpStrTokens []string) string {
	explanation := ""
	if len(helpStrTokens) > 0 && helpStrTokens[0] == "core:ignore" {
		return ""
	}
	if len(helpStrTokens) == 1 {
		explanation = helpStrTokens[0]
	} else if len(helpStrTokens) == 0 {
		explanation = ""
	} else {
		explanation = strings.Join(helpStrTokens, "\n")
	}
	helpStr := fmt.Sprintf("%s\n\ntype(%s) = '%s'\ninspect(%s) = '%s'", explanation, functionName, object.FUNCTION_OBJ, functionName, funObjString)
	return helpStr
}

func (c *Compiler) emitSetSymbolOpcode(symbol Symbol, immutable bool) {
	var opcode code.Opcode
	switch symbol.Scope {
	case GlobalScope:
		if immutable {
			opcode = code.OpSetGlobalImm
		} else {
			opcode = code.OpSetGlobal
		}
	case LocalScope:
		if immutable {
			opcode = code.OpSetLocalImm
		} else {
			opcode = code.OpSetLocal
		}
	}
	c.emit(opcode, symbol.Index)
}

func (c *Compiler) compileStringLiteral(node *ast.StringLiteral) error {
	var literal *object.Stringo
	if node.Value == object.USE_PARAM_STR {
		literal = object.USE_PARAM_STR_OBJ
	} else {
		literal = &object.Stringo{Value: node.Value}
	}
	origStrIndex := c.addConstant(literal)
	c.emit(code.OpConstant, origStrIndex)
	if len(node.InterpolationValues) != 0 {
		for i, interp := range node.InterpolationValues {
			err := c.Compile(interp)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			s := node.OriginalInterpolationString[i]
			c.emit(code.OpConstant, c.addConstant(&object.Stringo{Value: s}))
		}
		c.emit(code.OpStringInterp, origStrIndex, len(node.InterpolationValues)*2)
	}
	return nil
}
