package compiler

import (
	"blue/ast"
	"blue/bluec"
	"blue/blueutil"
	"blue/code"
	"blue/consts"
	"blue/lexer"
	"blue/object"
	"blue/token"
	"bytes"
	"fmt"
	"log"
	"os"
	"regexp"
	"sort"
)

type EmittedInstruction struct {
	Opcode   code.Opcode
	Position int
}

const cCompilerBasePath = "."

type Compiler struct {
	constants     []object.Object
	constantFolds map[uint64]int

	symbolTable *SymbolTable

	scopes     []CompilationScope
	scopeIndex int

	ErrorTrace []string

	currentPos int

	forIndex int
	breakPos map[int][]int
	contPos  map[int][]int
	inTry    map[int]struct{}

	importNestLevel  int
	modName          []string
	CompilerBasePath string
	ValidModuleNames []string // TODO: Maybe eventually use map[string]struct{}

	// ReadFiles records the absolute paths of every user module file read
	// during this compilation (see compileImportStatement). It lets callers
	// such as the run cache know which sources the compiled image depends
	// on. It is per-compilation state, never shared between compilers.
	ReadFiles []string

	listSetMapCompLiteralIndex int

	coreCompiled bool

	inMatch bool

	tokens     []*token.Token
	tokenFolds map[token.Token]int
}

func (c *Compiler) DebugString() string {
	var out bytes.Buffer
	out.WriteString("Compiler{\n")
	fmt.Fprintf(&out, "\tconstanstLen: %d\n", len(c.constants))
	fmt.Fprintf(&out, "\tconstantFoldsLen: %d\n", len(c.constantFolds))
	fmt.Fprintf(&out, "\tsymbolTable: \n|\n%s\n|\n", c.symbolTable.String())
	fmt.Fprintf(&out, "\tscopes: %#+v\n", c.scopes)
	fmt.Fprintf(&out, "\tscopeIndex: %d\n", c.scopeIndex)
	fmt.Fprintf(&out, "\tErrorTrace: %#+v\n", c.ErrorTrace)
	fmt.Fprintf(&out, "\tcurrentPos: %d\n", c.currentPos)
	fmt.Fprintf(&out, "\tforIndex: %d\n", c.forIndex)
	fmt.Fprintf(&out, "\tbreakPos: %#+v\n", c.breakPos)
	fmt.Fprintf(&out, "\tcontPos: %#+v\n", c.contPos)
	fmt.Fprintf(&out, "\timportNestLevel: %d\n", c.importNestLevel)
	fmt.Fprintf(&out, "\tmodName: %#+v\n", c.modName)
	fmt.Fprintf(&out, "\tCompilerBasePath: %q\n", c.CompilerBasePath)
	fmt.Fprintf(&out, "\tValidModulesNames: %#+v\n", c.ValidModuleNames)
	fmt.Fprintf(&out, "\tlistSetMapCompLiteralIndex: %d\n", c.listSetMapCompLiteralIndex)
	fmt.Fprintf(&out, "\tcoreCompiled: %t\n", c.coreCompiled)
	fmt.Fprintf(&out, "\tinMatch: %t\n", c.inMatch)
	out.WriteString("}")
	return out.String()
}

type CompilationScope struct {
	instructions        code.Instructions
	lastInstruction     EmittedInstruction
	previousInstruction EmittedInstruction
}

func New() *Compiler {
	symbolTable := NewSymbolTable()
	for i, v := range object.AllBuiltins[0].Builtins {
		symbolTable.DefineBuiltin(i, v.Name, 0, v.Help())
	}
	for i, v := range object.BuiltinobjsList {
		symbolTable.DefineBuiltin(i, v.Name, object.BuiltinobjsModuleIndex, v.Builtin.Help())
	}
	mainScope := CompilationScope{
		instructions:        code.Instructions{},
		lastInstruction:     EmittedInstruction{},
		previousInstruction: EmittedInstruction{},
	}
	return &Compiler{
		constants:        object.OBJECT_CONSTANTS,
		constantFolds:    map[uint64]int{},
		symbolTable:      symbolTable,
		scopes:           []CompilationScope{mainScope},
		scopeIndex:       0,
		ErrorTrace:       []string{},
		currentPos:       0,
		forIndex:         0,
		breakPos:         map[int][]int{},
		contPos:          map[int][]int{},
		inTry:            map[int]struct{}{},
		importNestLevel:  -1,
		modName:          []string{},
		CompilerBasePath: cCompilerBasePath,
		tokens:           []*token.Token{},
		tokenFolds:       make(map[token.Token]int),
	}
}

func NewWithState(s *SymbolTable, constants []object.Object) *Compiler {
	compiler := New()
	compiler.symbolTable = s
	compiler.constants = constants
	return compiler
}

func NewWithStateAndCore(s *SymbolTable, constants []object.Object) *Compiler {
	c := NewWithState(s, constants)
	c.compileCore()
	return c
}

func NewFromCore() *Compiler {
	return newFromCore()
}

func (c *Compiler) SetDocModName(name string) {
	c.importNestLevel = 0
	c.modName = []string{name}
}

func (c *Compiler) GetDocOrderedPublicFunctionHelpString(modName string) string {
	return c.symbolTable.GetOrderedPublicFunctionHelpString(modName)
}

// Bytecode is an alias of bluec.Bytecode: the struct lives in package bluec
// so that packages which must not import the compiler (vm, minimal runners)
// can share the exact same type. See bluec.Bytecode.
type Bytecode = bluec.Bytecode

func (c *Compiler) Bytecode() *Bytecode {
	return &Bytecode{
		Instructions: c.currentInstructions(),
		Constants:    c.constants,
		Tokens:       c.tokens,
	}
}

func (c *Compiler) currentInstructions() code.Instructions {
	return c.scopes[c.scopeIndex].instructions
}

func (c *Compiler) addNode(node ast.Node) int {
	currentTok := node.TokenToken()
	tokPos, ok := c.tokenFolds[currentTok]
	if ok {
		return tokPos
	}
	c.tokens = append(c.tokens, &currentTok)
	index := len(c.tokens) - 1
	c.tokenFolds[currentTok] = index
	return index
}

func (c *Compiler) addConstant(obj object.Object) int {
	if index := object.IsConstantObject(obj); index != -1 {
		// return reserved index for constant object
		return index
	}
	hash, hashedIndex := c.isConstantFolded(obj)
	if hashedIndex != -1 {
		return hashedIndex
	}
	c.constants = append(c.constants, obj)
	index := len(c.constants) - 1
	c.constantFolds[hash] = index
	return index
}

func (c *Compiler) isConstantFolded(obj object.Object) (uint64, int) {
	ho := object.HashObject(obj)
	if index, ok := c.constantFolds[ho]; ok {
		return ho, index
	}
	return 0, -1
}

func (c *Compiler) emit(op code.Opcode, operands ...int) int {
	ins := code.Make(op, operands...)
	pos := c.addInstruction(ins)
	c.setLastInstruction(op, pos)
	return pos
}

// emitNode is only used for call expressions
func (c *Compiler) emitNode(node ast.Node) {
	c.emit(code.OpNode, c.addNode(node))
}

func (c *Compiler) addInstruction(ins []byte) int {
	posNewInstruction := len(c.currentInstructions())
	updatedInstructions := append(c.currentInstructions(), ins...)
	c.scopes[c.scopeIndex].instructions = updatedInstructions
	return posNewInstruction
}

func (c *Compiler) setLastInstruction(op code.Opcode, pos int) {
	if op == code.OpNode {
		// Do not set OpNode as Last Instruction
		return
	}
	previous := c.scopes[c.scopeIndex].lastInstruction
	last := EmittedInstruction{Opcode: op, Position: pos}
	c.scopes[c.scopeIndex].previousInstruction = previous
	c.scopes[c.scopeIndex].lastInstruction = last
}

func (c *Compiler) lastInstructionIs(op code.Opcode) bool {
	if len(c.currentInstructions()) == 0 {
		return false
	}
	return c.scopes[c.scopeIndex].lastInstruction.Opcode == op
}

func (c *Compiler) lastInstructionIsSet() bool {
	if len(c.currentInstructions()) == 0 {
		return false
	}
	currentOp := c.scopes[c.scopeIndex].lastInstruction.Opcode
	return currentOp == code.OpSetGlobal || currentOp == code.OpSetGlobalImm || currentOp == code.OpSetLocal || currentOp == code.OpSetLocalImm
}

func (c *Compiler) lastInstructionReturnsBool() bool {
	if len(c.currentInstructions()) == 0 {
		return false
	}
	currentOp := c.scopes[c.scopeIndex].lastInstruction.Opcode
	return currentOp == code.OpEqual || currentOp == code.OpNotEqual || currentOp == code.OpIn || currentOp == code.OpNotin || currentOp == code.OpNot || currentOp == code.OpOr || currentOp == code.OpAnd || currentOp == code.OpGreaterThan || currentOp == code.OpGreaterThanOrEqual
}

func (c *Compiler) removeLastPop() {
	c.removeLastInstruction()
}

func (c *Compiler) removeLastInstruction() {
	last := c.scopes[c.scopeIndex].lastInstruction
	previous := c.scopes[c.scopeIndex].previousInstruction
	old := c.currentInstructions()
	new := old[:last.Position]
	c.scopes[c.scopeIndex].instructions = new
	c.scopes[c.scopeIndex].lastInstruction = previous
}

func (c *Compiler) replaceLastPopWithReturn() {
	lastPos := c.scopes[c.scopeIndex].lastInstruction.Position
	c.replaceInstruction(lastPos, code.Make(code.OpReturnValue))
	c.scopes[c.scopeIndex].lastInstruction.Opcode = code.OpReturnValue
}

func (c *Compiler) replaceInstruction(pos int, newInstruction []byte) {
	instructions := c.currentInstructions()
	for i := range newInstruction {
		instructions[pos+i] = newInstruction[i]
	}
}

func (c *Compiler) changeOperand(opPos int, operand int) {
	op := code.Opcode(c.currentInstructions()[opPos])
	newInstruction := code.Make(op, operand)
	c.replaceInstruction(opPos, newInstruction)
}

func (c *Compiler) enterScope() {
	scope := CompilationScope{
		instructions:        code.Instructions{},
		lastInstruction:     EmittedInstruction{},
		previousInstruction: EmittedInstruction{},
	}
	c.scopes = append(c.scopes, scope)
	c.scopeIndex++
	c.symbolTable = NewEnclosedSymbolTable(c.symbolTable)
}

func (c *Compiler) leaveScope() code.Instructions {
	instructions := c.currentInstructions()
	c.scopes = c.scopes[:len(c.scopes)-1]
	c.scopeIndex--
	c.symbolTable = c.symbolTable.Outer
	return instructions
}

func (c *Compiler) addNodeToErrorTrace(err error, tok token.Token) error {
	c.ErrorTrace = append(c.ErrorTrace, fmt.Sprintf("%s\n", lexer.GetErrorLineMessage(tok)))
	return err
}

const ignoreStr = `Filepath: "", LineNumber: 0, PositionInLine: 0
`

func (c *Compiler) PrintStackTrace() {
	prevS := ""
	for _, s := range c.ErrorTrace {
		if s != prevS && s != ignoreStr {
			blueutil.PrintCustomError(os.Stdout, consts.COMPILER_ERROR_PREFIX, s, -1, false)
		}
		prevS = s
	}
}

func (c *Compiler) Compile(node ast.Node) error {
	switch node := node.(type) {
	case *ast.Program:
		for _, s := range node.Statements {
			c.currentPos = len(c.currentInstructions())
			err := c.Compile(s)
			if err != nil {
				return err
			}
			clear(c.ErrorTrace)
		}
	case *ast.ExpressionStatement:
		err := c.Compile(node.Expression)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		if !c.lastInstructionIsSet() {
			c.emit(code.OpPop)
		}
	case *ast.InfixExpression:
		c.emitNode(node)
		switch node.Operator {
		case "<", "<=":
			err := c.Compile(node.Right)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			err = c.Compile(node.Left)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			err = c.compileInfixExpression(node.Operator)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			return nil
		case "or", "||":
			// Handle Shortcut 'or' compiling
			err := c.Compile(node.Left)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			c.emit(code.OpNotIfNotNull)
			jumpNotTruthyPos := c.emit(code.OpJumpNotTruthyAndPushTrue, 9999)
			err = c.Compile(node.Right)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			c.emit(code.OpOr)
			c.changeOperand(jumpNotTruthyPos, len(c.currentInstructions()))
			return nil
		case "and", "&&":
			// Handle Shortcut 'and' compiling
			err := c.Compile(node.Left)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			jumpNotTruthyPos := c.emit(code.OpJumpNotTruthyAndPushFalse, 9999)
			err = c.Compile(node.Right)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			c.emit(code.OpAnd)
			c.changeOperand(jumpNotTruthyPos, len(c.currentInstructions()))
			return nil
		}
		err := c.Compile(node.Left)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		err = c.Compile(node.Right)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		err = c.compileInfixExpression(node.Operator)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.PrefixExpression:
		c.emitNode(node)
		err := c.Compile(node.Right)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		switch node.Operator {
		case "!", "not":
			c.emit(code.OpNot)
		case "-":
			c.emit(code.OpNeg)
		case "~":
			c.emit(code.OpTilde)
		case "<<":
			c.emit(code.OpLshiftPre)
		default:
			return fmt.Errorf("unknown operator %s", node.Operator)
		}
	case *ast.PostfixExpression:
		c.emitNode(node)
		err := c.Compile(node.Left)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		if node.Operator == ">>" {
			c.emit(code.OpRshiftPost)
		} else {
			return fmt.Errorf("unknown operator %s", node.Operator)
		}
	case *ast.IntegerLiteral:
		literal := &object.Integer{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.BigIntegerLiteral:
		literal := &object.BigInteger{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.HexLiteral:
		literal := &object.UInteger{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.OctalLiteral:
		literal := &object.UInteger{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.BinaryLiteral:
		literal := &object.UInteger{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.UIntegerLiteral:
		literal := &object.UInteger{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.FloatLiteral:
		literal := &object.Float{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.BigFloatLiteral:
		literal := &object.BigFloat{Value: node.Value}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.RegexLiteral:
		r, err := regexp.Compile(node.Token.Literal)
		if err != nil {
			return fmt.Errorf("failed to create regex literal %q", node.TokenLiteral())
		}
		literal := &object.Regex{Value: r}
		c.emit(code.OpConstant, c.addConstant(literal))
	case *ast.StringLiteral:
		err := c.compileStringLiteral(node)
		if err != nil {
			// Error token attached inside above function
			return err
		}
	case *ast.ListLiteral:
		for _, exp := range node.Elements {
			err := c.Compile(exp)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
		}
		// Note: this is needed for list comp literals to work properly
		// a similar thing is done in evaluator
		if !c.lastInstructionIs(code.OpListCompLiteral) {
			c.emit(code.OpList, len(node.Elements))
		}
	case *ast.SetLiteral:
		if !c.lastInstructionIs(code.OpSetCompLiteral) {
			for _, exp := range node.Elements {
				err := c.Compile(exp)
				if err != nil {
					return c.addNodeToErrorTrace(err, node.Token)
				}
			}
			c.emit(code.OpSet, len(node.Elements))
		}
	case *ast.MapLiteral:
		c.emitNode(node)
		indices := make([]int, 0, len(node.PairsIndex))
		for k := range node.PairsIndex {
			indices = append(indices, k)
		}
		sort.Ints(indices)
		for _, i := range indices {
			keyNode := node.PairsIndex[i]
			keyNode1 := keyNode
			// Support keys in map without requiring quotes
			if ident, ok := keyNode.(*ast.Identifier); ok {
				if obj, ok1 := c.symbolTable.Resolve(c.getName(ident.Value)); !ok1 {
					keyNode1 = &ast.StringLiteral{Value: ident.Value}
				} else if obj.Scope == BuiltinScope {
					keyNode1 = &ast.StringLiteral{Value: ident.Value}
				}
			}
			err := c.Compile(keyNode1)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
			valueNode := node.Pairs[keyNode]
			err = c.Compile(valueNode)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
		}
		c.emit(code.OpMap, len(node.Pairs)*2)
	case *ast.Boolean:
		if node.Value {
			c.emit(code.OpTrue)
		} else {
			c.emit(code.OpFalse)
		}
	case *ast.Null:
		c.emit(code.OpNull)
	case *ast.IfExpression:
		c.emitNode(node)
		err := c.compileIfExpression(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.BlockStatement:
		c.enterBlock()
		for _, s := range node.Statements {
			err := c.Compile(s)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
		}
		c.exitBlock()
	case *ast.VarStatement:
		err := c.compileVarValStatements(node)
		if err != nil {
			return err
		}
	case *ast.ValStatement:
		err := c.compileVarValStatements(node)
		if err != nil {
			return err
		}
	case *ast.AssignmentExpression:
		c.emitNode(node)
		err := c.compileAssignmentExpression(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.Identifier:
		c.emitNode(node)
		if c.inMatch && node.Value == "_" {
			c.emit(code.OpMatchAny)
		} else {
			var dontEmitSymbol bool
			// Always try to resolve for local scope first, then try all the others
			symbol, ok := c.symbolTable.Resolve(node.Value)
			if !ok || symbol.Scope != LocalScope {
				symbol, ok = c.symbolTable.Resolve(c.getName(node.Value))
				if !ok {
					// Due to the way compiling works, if its a builtin we need to try again
					symbol, ok = c.symbolTable.Resolve(node.Value)
					if !ok {
						// Allow resolving special scope symbols
						symbol, ok, dontEmitSymbol = c.symbolTable.ResolveSpecial(node.Value, c.scopeIndex)
						if !ok {
							return fmt.Errorf("identifier not found %s\n%s", node.Value, lexer.GetErrorLineMessage(node.Token))
						}
						if dontEmitSymbol {
							c.emit(code.OpGetFunctionParameterSpecial2, c.addConstant(&object.Stringo{Value: node.Value}))
						}
					}
				}
			}
			if !dontEmitSymbol {
				c.loadSymbol(symbol)
			}
		}
	case *ast.IndexExpression:
		err := c.compileIndexExpression(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.FunctionLiteral:
		// A function body is not part of the pattern being matched so '_' inside
		// of it must not be treated as a match wildcard
		prevInMatch := c.inMatch
		c.inMatch = false
		c.enterScope()
		compiledFun := c.setupFunction(node.Parameters, node.ParameterExpressions, node.Body, node.String())
		compiledFun.HelpStr = object.CreateHelpStringFromBodyTokens("", compiledFun, node.Body.HelpStrTokens)
		err := c.Compile(node.Body)
		if err != nil {
			c.inMatch = prevInMatch
			return c.addNodeToErrorTrace(err, node.Token)
		}
		if c.lastInstructionIs(code.OpPop) {
			c.replaceLastPopWithReturn()
		}
		if !c.lastInstructionIs(code.OpReturnValue) {
			c.emit(code.OpReturn)
		}
		freeSymbols := c.symbolTable.FreeSymbols
		numLocals := c.symbolTable.NumLocals()
		instructions := c.leaveScope()
		for _, s := range freeSymbols {
			c.loadSymbol(s)
		}
		compiledFun.Instructions = instructions
		compiledFun.NumLocals = numLocals
		funIndex := c.addConstant(compiledFun)
		c.emit(code.OpClosure, funIndex, len(freeSymbols))
		c.inMatch = prevInMatch
	case *ast.FunctionStatement:
		// A function body is not part of the pattern being matched so '_' inside
		// of it must not be treated as a match wildcard
		prevInMatch := c.inMatch
		c.inMatch = false
		helpStr := createHelpStringFromAstFunction(node.Name.Value, node.String(), node.Body.HelpStrTokens)
		symbol := c.symbolTable.DefineFun(c.getName(node.Name.Value), true, node.Parameters, node.ParameterExpressions, helpStr)
		c.enterScope()
		compiledFun := c.setupFunction(node.Parameters, node.ParameterExpressions, node.Body, node.String())
		compiledFun.HelpStr = symbol.HelpStr
		err := c.Compile(node.Body)
		if err != nil {
			c.inMatch = prevInMatch
			return c.addNodeToErrorTrace(err, node.Token)
		}
		if c.lastInstructionIs(code.OpPop) {
			c.replaceLastPopWithReturn()
		}
		if !c.lastInstructionIs(code.OpReturnValue) {
			c.emit(code.OpReturn)
		}
		freeSymbols := c.symbolTable.FreeSymbols
		numLocals := c.symbolTable.NumLocals()
		instructions := c.leaveScope()
		for _, s := range freeSymbols {
			c.loadSymbol(s)
		}
		compiledFun.Instructions = instructions
		compiledFun.NumLocals = numLocals
		funIndex := c.addConstant(compiledFun)
		c.emit(code.OpClosure, funIndex, len(freeSymbols))
		switch symbol.Scope {
		case GlobalScope:
			c.emit(code.OpSetGlobalImm, symbol.Index)
		case LocalScope:
			c.emit(code.OpSetLocalImm, symbol.Index)
		}
		c.inMatch = prevInMatch
	case *ast.ReturnStatement:
		c.emitNode(node)
		err := c.Compile(node.ReturnValue)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		c.emit(code.OpReturnValue)
	case *ast.CallExpression:
		err := c.compileCallExpression(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.ForStatement:
		c.emitNode(node)
		c.enterBlock()
		err := c.compileForStatement(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		c.exitBlock()
	case *ast.BreakStatement:
		// Set not in try for VM so once we jump its correct
		// (if we hit an error in try that would proc first)
		if _, ok := c.inTry[c.symbolTable.BlockNestLevel]; ok {
			c.emit(code.OpNotInTry)
		}
		pos := c.emit(code.OpJump, 9999)
		if c.breakPos[c.forIndex] == nil {
			c.breakPos[c.forIndex] = []int{}
		}
		c.breakPos[c.forIndex] = append(c.breakPos[c.forIndex], pos)
	case *ast.ContinueStatement:
		c.emit(code.OpNotInCatch)
		pos := c.emit(code.OpJump, 9999)
		if c.contPos[c.forIndex] == nil {
			c.contPos[c.forIndex] = []int{}
		}
		c.contPos[c.forIndex] = append(c.contPos[c.forIndex], pos)
	case *ast.TryCatchStatement:
		c.emitNode(node)
		c.currentPos = len(c.currentInstructions())
		c.enterBlock()
		c.inTry[c.symbolTable.BlockNestLevel] = struct{}{}
		c.emit(code.OpTry)
		err := c.Compile(node.TryBlock)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.TryBlock.Token)
		}
		delete(c.inTry, c.symbolTable.BlockNestLevel)
		c.exitBlock()
		if node.CatchBlock != nil {
			c.currentPos = len(c.currentInstructions())
			c.enterBlock()
			c.emit(code.OpCatch)
			symbol := c.symbolTable.Define(node.CatchIdentifier.Value, true)
			switch symbol.Scope {
			case GlobalScope:
				c.emit(code.OpSetGlobalImm, symbol.Index)
			case LocalScope:
				c.emit(code.OpSetLocalImm, symbol.Index)
			}
			err := c.Compile(node.CatchIdentifier)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.CatchBlock.Token)
			}
			err = c.Compile(node.CatchBlock)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.CatchBlock.Token)
			}
			c.emit(code.OpCatchEnd)
			c.exitBlock()
		}
		if node.FinallyBlock != nil {
			c.currentPos = len(c.currentInstructions())
			c.enterBlock()
			c.emit(code.OpFinally)
			err := c.Compile(node.FinallyBlock)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.FinallyBlock.Token)
			}
			c.exitBlock()
			c.emit(code.OpFinallyEnd)
		}
	case *ast.ImportStatement:
		savedBlockNestLevel := c.symbolTable.BlockNestLevel
		c.symbolTable.BlockNestLevel = -1
		err := c.compileImportStatement(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		c.symbolTable.BlockNestLevel = savedBlockNestLevel
	case *ast.ListCompLiteral:
		err := c.compileListCompLiteral(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.SetCompLiteral:
		err := c.compileSetCompLiteral(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.MapCompLiteral:
		err := c.compileMapCompLiteral(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.MatchExpression:
		c.emitNode(node)
		err := c.compileMatchExpression(node)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
	case *ast.EvalExpression:
		err := c.Compile(node.StrToEval)
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		c.emitNode(node)
		c.emit(code.OpEval)
	case *ast.ExecStringLiteral:
		c.emitNode(node)
		if node.Value == "" {
			err := fmt.Errorf("exec string must not be empty")
			return c.addNodeToErrorTrace(err, node.Token)
		}
		literal := &object.ExecString{Value: node.Value}
		c.emit(code.OpExecString, c.addConstant(literal))
	case *ast.StructLiteral:
		c.emitNode(node)
		c.emit(code.OpConstant, c.addConstant(object.NewGoObj(node.Fields)))
		for _, exp := range node.Values {
			err := c.Compile(exp)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
		}
		c.emit(code.OpStruct, len(node.Fields))
	case *ast.DeferExpression:
		c.emitNode(node)
		for _, arg := range node.Arguments {
			err := c.Compile(arg)
			if err != nil {
				return c.addNodeToErrorTrace(err, node.Token)
			}
		}
		c.emit(code.OpDefer, len(node.Arguments))
	case *ast.SelfExpression:
		c.emitNode(node)
		c.emit(code.OpSelf)
	case *ast.SpawnExpression:
		argLen := len(node.Arguments)
		if argLen > 2 || argLen == 0 {
			return c.addNodeToErrorTrace(fmt.Errorf("InvalidArgCountError: `spawn` wrong number of arguments. got=%d, want=1 or 2", argLen), node.Token)
		}
		err := c.Compile(node.Arguments[0])
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Arguments[0].TokenToken())
		}
		if argLen == 2 {
			err = c.Compile(node.Arguments[1])
		} else {
			// Compile Empty List as a placeholder arg
			err = c.Compile(&ast.ListLiteral{Elements: []ast.Expression{}})
		}
		if err != nil {
			return c.addNodeToErrorTrace(err, node.Token)
		}
		c.emitNode(node)
		c.emit(code.OpSpawn, argLen)
	default:
		log.Fatalf("Failed to compile %T %+#v", node, node)
	}
	return nil
}
