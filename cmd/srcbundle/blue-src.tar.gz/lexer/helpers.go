package lexer

import (
	"blue/token"
	"unicode"
)

func (l *Lexer) newToken(tokenType token.Type, ch rune) token.Token {
	return token.Token{Type: tokenType, Literal: string(ch), LineNumber: l.lineNo, PositionInLine: l.posInLine - 1, Filepath: l.fname}
}

// makeTwoCharToken takes a tokens type and returns the new token
// while advancing the readPosition and current char
func (l *Lexer) makeTwoCharToken(typ token.Type) token.Token {
	ch := l.ch
	lineNo := l.lineNo
	posInLine := l.posInLine
	// consume next char because we know it is an =
	l.readChar()
	return token.Token{Type: typ, Literal: string(ch) + string(l.ch), LineNumber: lineNo, PositionInLine: posInLine, Filepath: l.fname}
}

// makeThreeCharToken takes a tokens type and returns the new token
// while advancing the readPosition and current char to the proper position
func (l *Lexer) makeThreeCharToken(typ token.Type) token.Token {
	ch := l.ch
	lineNo := l.lineNo
	posInLine := l.posInLine
	l.readChar()
	ch1 := l.ch
	l.readChar()
	return token.Token{Type: typ, Literal: string(ch) + string(ch1) + string(l.ch), LineNumber: lineNo, PositionInLine: posInLine, Filepath: l.fname}
}

// isLetter will return true if the rune given matches the pattern below
// 'a' <= ch && ch <= 'z' || 'A' <= ch && ch <= 'Z' || ch == '_'
func isLetter(ch rune) bool {
	return unicode.IsLetter(rune(ch)) || ch == '_'
}

// isIdentifierChar will return true if the rune given is allowed as part of
// an identifier after the first character (see readIdentifier)
//
// Note: the first character of an identifier must match isLetter since
// identifiers cannot start with a number or one of the trailing chars below
func isIdentifierChar(ch rune) bool {
	return isLetter(ch) || unicode.IsNumber(ch) || ch == '?' || ch == '!'
}

// isImportChar will return true if the rune given is allowed as part of an import path
//
// Note: import paths allow everything that identifiers allow (see isIdentifierChar)
// so module names such as mod2 lex consistently at import sites and usage sites.
// The reason why '.' is allowed is because that will signifiy the path separation
// in the import path.
//
// We could just use a basic string which would solve most of these problems but i like
// the look of python's import syntax :)
func isImportChar(ch rune) bool {
	return isIdentifierChar(ch) || ch == '.'
}

// isDigit will return true if the rune give is 0-9 or any unicode Digit
func isDigit(ch rune) bool {
	return unicode.IsDigit(ch)
}

// isHexChar will return true if the rune given is a hex character
func isHexChar(ch rune) bool {
	return 'a' <= ch && ch <= 'f' || 'A' <= ch && ch <= 'F' || '0' <= ch && ch <= '9'
}

// isOctalChar will return true if the rune given is an octal character
func isOctalChar(ch rune) bool {
	return '0' <= ch && ch <= '7'
}

// isBinaryChar will return true if the rune given is a binary character
func isBinaryChar(ch rune) bool {
	return ch == '0' || ch == '1'
}
