package consts

import (
	"io"
	"os"
	"runtime/debug"

	"github.com/gookit/color"
)

// versionNumber is the current version #
const versionNumber = "0.3.7"

// BaseVersion returns the bare version number without VCS or flavor
// suffixes. Image fingerprints and the run cache key on this instead of
// the full VERSION so builds from exported source trees (which carry no
// git metadata) match builds from checkouts. Opcode, constant and tag
// components still guard real incompatibilities.
func BaseVersion() string {
	return versionNumber
}

// ShortVersion returns the version without VCS metadata, keeping the
// flavor suffix (e.g. "0.3.7-static"). This is the default `blue version`
// output.
func ShortVersion() string {
	return versionNumber + versionSuffix
}

// FullVersion returns the version with VCS metadata when built from git
// (e.g. "0.3.7-12700ab-linux/amd64"). Shown by `blue version --full`.
func FullVersion() string {
	return VERSION
}

// versionFn is the function that returns the formatted version number of the blang repl and language
func versionFn() string {
	hash := ""
	os := ""
	arch := ""
	if info, ok := debug.ReadBuildInfo(); ok {
		for _, setting := range info.Settings {
			if setting.Key == "vcs.revision" {
				// This is the short hash
				hash = setting.Value[:7]
			}
			if setting.Key == "GOOS" {
				os = setting.Value
			}
			if setting.Key == "GOARCH" {
				arch = setting.Value
			}
		}
	}
	if hash == "" {
		return versionNumber
	}
	versionStr := versionNumber + "-" + hash + "-" + os + "/" + arch
	return versionStr
}

const PARSER_ERROR_PREFIX = "[ERROR] ParserError: "
const COMPILER_ERROR_PREFIX = "[ERROR] CompilerError: "
const PROCESS_ERROR_PREFIX = "[ERROR] ProcessError: "
const EVAL_ERROR_PREFIX = "[ERROR] EvaluatorError: "
const VM_ERROR_PREFIX = "[ERROR] VMError: "

const CORE_FILE_PATH = "<embed:core/core.b>"

const INTERNAL_ERROR_PATTERN = "Filepath: \"<internal:"

const BLUE_INSTALL_PATH = "BLUE_INSTALL_PATH"
const BLUE_NO_COLOR = "BLUE_NO_COLOR"
const BLUE_DISABLE_HTTP_SERVER_DEBUG = "BLUE_DISABLE_HTTP_SERVER_DEBUG"
const BLUE_NO_CACHE = "BLUE_NO_CACHE"

// CACHE_DIR_NAME is the name of the folder created next to a run .b file to
// hold its compiled program image so later runs skip lexing/parsing/compiling.
const CACHE_DIR_NAME = "__blue_cache"

const EMBED_FILES_PREFIX = "embed_files/"

const NORMAL_EXIT_ON_RETURN = "normal exit on return"

var ErrorPrinter = func(format string, a ...any) {
	// Errors go to STDERR so that they do not mix with program output
	_, _ = io.WriteString(os.Stderr, color.New(color.FgRed, color.Bold).Sprintf(format, a...))
}
var InfoPrinter = color.New(color.FgBlue, color.Bold).Printf

func DisableColorIfNoColorEnvVarSet() {
	if os.Getenv(BLUE_NO_COLOR) != "" || os.Getenv("NO_COLOR") != "" {
		color.Disable()
	}
}
