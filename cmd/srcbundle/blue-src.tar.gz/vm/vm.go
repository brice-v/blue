package vm

import (
	"blue/bluec"
	"blue/blueutil"
	"blue/code"
	"blue/consts"
	"blue/object"
	"blue/token"
	"fmt"
	"log"
	"math/big"
	"strings"
	"sync"
)

const (
	StackSize   = 2048
	GlobalsSize = 65536
	MaxFrames   = 1024
)

type VM struct {
	constants   []object.Object
	tokens      []*token.Token
	lastNodePos int
	stack       []object.Object
	sp          int // Always points to the next value. Top of stack is stack[sp-1]

	globals []object.Object

	// globalsOwned reports whether this vm may write to vm.globals directly.
	// Connection vms start out sharing their parent's globals slice and copy
	// it on first write (see ensureGlobalWritable).
	globalsOwned bool

	// globalsHighWater is one past the highest global index ever written by
	// this vm. Globals are only ever appended to (symbol table indices are
	// assigned at compile time), so slots at or above it are still nil; the
	// spawn-time snapshot in Clone only needs to visit the used prefix.
	globalsHighWater int

	// Frames are stored by value in a preallocated array. currentFrame
	// returns a pointer into the array, so frame access in the interpreter
	// loop does not allocate (a *Frame was previously heap allocated per
	// function call). The slice header is swapped out by applyFunctionFast
	// and restored afterwards; the array itself is never reallocated or
	// grown, so pointers into it stay valid for the vm's lifetime.
	frames      []Frame
	framesIndex int

	TokensForErrorTrace []*token.Token

	// Process things
	NodeName string
	PID      uint64

	// Builtins that use vm
	builtinFuns map[string]func(args ...object.Object) object.Object

	// Cached vm bound builtin objects, keyed by builtin name. The global
	// builtin definitions are shared across vms and must never be written to.
	builtinObjs map[string]*object.Builtin

	// wsTemplate is the snapshot source for ws connection vms, created on the
	// first _handle_ws resolution and shared by every vm in the lineage.
	wsTemplate *VM

	// execMu serializes http handler execution. The stack, frames, globals
	// and closure special parameter maps are not safe for concurrent runs.
	execMu sync.Mutex

	// framesChanged is set when catch/finally unwinding rewrites
	// framesIndex or a frame's ip outside of the interpreter loop's local
	// tracking (see gotoNextCatchOrFinally and gotoCatchEnd). The Run loop
	// caches frame/ins/ip in locals across instructions and consults this
	// flag to resync from vm state instead of refetching every iteration.
	framesChanged bool
}

func (vm *VM) currentFrame() *Frame {
	return &vm.frames[vm.framesIndex-1]
}

func (vm *VM) popFrame() *Frame {
	var f *Frame
	if vm.framesIndex-1 == 0 {
		f = &vm.frames[vm.framesIndex]
	} else {
		vm.framesIndex--
		f = &vm.frames[vm.framesIndex]
	}
	// Slots that were never initialized have a nil closure; report them as
	// a nil frame so callers keep their previous "no frame here" behavior
	// (eg. the NORMAL_EXIT_ON_RETURN escape in Run).
	if f.cl == nil {
		return nil
	}
	return f
}

// lazyFramesFloor is the initial capacity of a vm's frame array. Frames
// grow geometrically up to MaxFrames on demand (see growFramesIfNeeded),
// so short scripts never pay for a 1024-slot array (~80 KB) up front.
const lazyFramesFloor = 32

// growFramesIfNeeded doubles the frame array when the next slot would fall
// off the end. Growth copies the live prefix; callers must not hold *Frame
// pointers across operations that can push frames - the interpreter already
// re-fetches via currentFrame() after every such operation (the same
// discipline that makes applyFunctionFast's array swapping safe).
func (vm *VM) growFramesIfNeeded() {
	if vm.framesIndex < len(vm.frames) || len(vm.frames) >= MaxFrames {
		return
	}
	newSize := len(vm.frames) * 2
	if newSize > MaxFrames {
		newSize = MaxFrames
	}
	newFrames := make([]Frame, newSize)
	copy(newFrames, vm.frames[:vm.framesIndex])
	vm.frames = newFrames
}

// newCallFrame initializes the next frame slot in place and returns a pointer
// to it, avoiding a heap allocation per function call. The caller must bump
// framesIndex or overwrite the current slot (fast-frame call).
func (vm *VM) newCallFrame(cl *object.Closure, bp int) *Frame {
	vm.growFramesIfNeeded()
	f := &vm.frames[vm.framesIndex]
	f.cl = cl
	f.ip = -1
	f.bp = bp
	f.lastInstruction = code.OpInvalid
	f.callerLastNodePos = -1
	f.deferFuns = nil
	f.inTry = false
	f.inCatch = false
	f.catchError = ""
	f.methodCallPending = false
	return f
}

// newCallFrameReplaceTop initializes the current top slot in place, replacing
// whatever frame is there without growing the frame stack (fast-frame calls).
func (vm *VM) newCallFrameReplaceTop(cl *object.Closure, bp int) *Frame {
	vm.framesIndex--
	f := vm.newCallFrame(cl, bp)
	vm.framesIndex++
	return f
}

func NewNode(nodeName string, bytecode *bluec.Bytecode) *VM {
	mainFn := &object.CompiledFunction{Instructions: bytecode.Instructions}
	mainClosure := &object.Closure{Fun: mainFn}
	frames := make([]Frame, lazyFramesFloor)
	frames[0] = *NewFrame(mainClosure, 0)
	// Reserve the pid atomically via Add(1), like executeSpawn does. A
	// plain Load() let two vms share a pid: spawned children take their
	// pids from the same counter, so a main vm reading Load() could get
	// the same pid as an in-flight child. The loser of the subsequent
	// ProcessMap.LoadOrStore race then holds a process whose channel gets
	// closed when the child exits (send on it panics, recv fails).
	vm := &VM{
		constants:    bytecode.Constants,
		tokens:       bytecode.Tokens,
		lastNodePos:  -1,
		stack:        make([]object.Object, StackSize),
		sp:           0,
		globalsOwned: true,
		frames:       frames,
		framesIndex:  1,
		PID:          object.PidCount.Add(1),
		NodeName:     nodeName,
	}
	// Create an empty process so we can recv without spawning
	process := &object.Process{
		// TODO: Eventually update to non-buffered and update send and recv as needed
		Ch: make(chan object.Object, 1),
		Id: vm.PID,

		NodeName: nodeName,
	}
	object.ProcessMap.LoadOrStore(object.Pk(nodeName, vm.PID), process)
	return vm
}

func New(bytecode *bluec.Bytecode) *VM {
	return NewNode("vm-node", bytecode)
}

func NewWithGlobalsStore(bytecode *bluec.Bytecode, s []object.Object) *VM {
	vm := New(bytecode)
	vm.globals = s
	vm.globalsOwned = true
	return vm
}

// Clone returns a vm suitable for running blue code concurrently with this
// one (process spawn, ws registration snapshot). Immutable program data
// (constants, tokens) is shared instead of deep cloned, globals are deep
// copied so the clone sees a spawn-time snapshot that later writes by either
// side do not affect, and execution state (stack, frames) starts fresh -
// callers immediately run a function on the clone via applyFunctionFast*,
// which swaps in its own frames and never reads stack contents below sp.
func (vm *VM) Clone(pid uint64) *VM {
	frames := make([]Frame, lazyFramesFloor)
	frames[0] = *NewFrame(emptyMainClosure, 0)
	return &VM{
		constants:    vm.constants,
		tokens:       vm.tokens,
		stack:        make([]object.Object, StackSize),
		sp:           0,
		globals:      object.CloneGlobals(vm.globals, vm.globalsHighWater),
		globalsOwned: true,
		frames:       frames,
		framesIndex:  1,
		lastNodePos:  -1,
		NodeName:     vm.NodeName,
		PID:          pid,
		wsTemplate:   vm.wsTemplate,
	}
}

// CloneForConnection returns a vm that can execute blue code concurrently
// with vm and other connection clones. Immutable program data (constants,
// tokens) is shared, globals are shared copy on write, and only the execution
// state (stack, frames) is private. This keeps per connection memory flat
// instead of deep cloning the whole program for every connection.
func (vm *VM) CloneForConnection(pid uint64) *VM {
	frames := make([]Frame, lazyFramesFloor)
	frames[0] = *NewFrame(emptyMainClosure, 0)
	return &VM{
		constants:   vm.constants,
		tokens:      vm.tokens,
		stack:       make([]object.Object, StackSize),
		sp:          0,
		globals:     vm.globals,
		frames:      frames,
		framesIndex: 1,
		lastNodePos: -1,
		NodeName:    vm.NodeName,
		PID:         pid,
		wsTemplate:  vm.wsTemplate,
	}
}

// ensureGlobalWritable makes vm.globals safe to write at index. Globals are
// lazily sized: fresh vms start with no backing store and grow geometrically
// up to GlobalsSize on first write, so short scripts never pay for a full
// 64k-slot table (allocation + GC scanning of 1 MB of pointers). Slices
// shared with sibling vms are copied first (copy-on-write).
func (vm *VM) ensureGlobalWritable(index int) {
	if index < len(vm.globals) && vm.globalsOwned {
		return // hot path: already owned and big enough
	}
	newSize := len(vm.globals)
	if index >= newSize {
		// Grow geometrically; indices are uint16 operands so they always
		// fit within GlobalsSize.
		newSize *= 2
		if newSize <= index {
			newSize = index + 1
		}
		if newSize < lazyGlobalsFloor {
			newSize = lazyGlobalsFloor
		}
		if newSize > GlobalsSize {
			newSize = GlobalsSize
		}
	}
	newGlobals := make([]object.Object, newSize)
	copy(newGlobals, vm.globals)
	vm.globals = newGlobals
	vm.globalsOwned = true
}

// lazyGlobalsFloor is the initial size of a vm's lazily allocated globals
// store, large enough that typical scripts never reallocate.
const lazyGlobalsFloor = 128

// SetGlobalsHighWater records that global slots below n hold values written
// outside of the interpreter loop (the repl stores per-line results
// directly into the shared store between runs), so spawn-time snapshots
// include them.
func (vm *VM) SetGlobalsHighWater(n int) {
	if n > vm.globalsHighWater {
		vm.globalsHighWater = n
	}
}

// GlobalsHighWater returns one past the highest global index ever written
// through this vm (or seeded via SetGlobalsHighWater).
func (vm *VM) GlobalsHighWater() int {
	return vm.globalsHighWater
}

func (vm *VM) StackTop() object.Object {
	if vm.sp == 0 {
		return nil
	}
	return vm.stack[vm.sp-1]
}

func (vm *VM) PushAndReturnError(err error) error {
	if vm.currentFrame().inTry {
		_ = vm.push(newError("%s", err.Error()))
		return nil
	}
	return err
}

func (vm *VM) Run() error {
	var op code.Opcode
	// frame/ins/ip are cached across instructions and only resynced from vm
	// state when frames change (calls, returns, catch unwinding). frame.ip
	// is stored before each dispatch because handlers and exception
	// scanning read it mid-handler.
	frame := vm.currentFrame()
	ins := frame.Instructions()
	ip := frame.ip
	for ip < len(ins)-1 {
		ip++
		frame.ip = ip
		op = code.Opcode(ins[ip])
		if op == code.OpNode {
			vm.lastNodePos = ip
			// Skip TokenIndex of OpNode
			ip += 2
			continue
		}
		opPos := ip
		switch op {
		case code.OpConstant:
			constIndex := code.ReadUint16(ins[ip+1:])
			ip += 2
			if int(constIndex) > len(vm.constants) {
				return fmt.Errorf("constant index out of bounds, got=%d, len=%d", constIndex, len(vm.constants))
			}
			err := vm.push(vm.constants[constIndex])
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpTrue:
			err := vm.push(object.TRUE)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpFalse:
			err := vm.push(object.FALSE)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpNull:
			err := vm.push(object.NULL)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpPop:
			vm.pop()
		case code.OpAdd, code.OpMinus, code.OpStar, code.OpPow, code.OpDiv,
			code.OpFlDiv, code.OpPercent, code.OpCarat, code.OpAmpersand,
			code.OpPipe, code.OpIn, code.OpNotin, code.OpRange, code.OpNonIncRange,
			code.OpAnd, code.OpEqual, code.OpNotEqual, code.OpOr, code.OpGreaterThan, code.OpGreaterThanOrEqual,
			code.OpRshift, code.OpLshift:
			err := vm.executeBinaryOperation(op)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpNot:
			err := vm.executeNotOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpNotIfNotNull:
			err := vm.executeNotIfNotNullOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpNeg:
			err := vm.executeNegOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpTilde:
			err := vm.executeBitwiseNotOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpLshiftPre:
			err := vm.executeLshiftPrefixOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpRshiftPost:
			err := vm.executeRshiftPostfixOperation()
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpJump:
			pos := int(code.ReadUint16(ins[ip+1:]))
			ip = pos - 1
		case code.OpJumpNotTruthy:
			pos := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			condition := vm.pop()
			if !isTruthy(condition) {
				ip = pos - 1
			}
		case code.OpJumpNotTruthyAndPushTrue:
			pos := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			// Pass null through (as this would mean we should re-push the item on the stack)
			if vm.peek() != object.NULL {
				condition := vm.pop()
				if !isTruthy(condition) {
					ip = pos - 1
					err := vm.push(object.TRUE)
					if err != nil {
						err = vm.PushAndReturnError(err)
						if err != nil {
							return err
						}
					}
				} else {
					// Execute Not on the Condition to reverse OpNotIfNotNull which is always called prior
					err := vm.push(condition)
					if err != nil {
						return err
					}
					err = vm.executeNotOperation()
					if err != nil {
						return err
					}
				}
			}
		case code.OpJumpNotTruthyAndPushFalse:
			pos := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			condition := vm.pop()
			if !isTruthy(condition) {
				ip = pos - 1
				err := vm.push(object.FALSE)
				if err != nil {
					err = vm.PushAndReturnError(err)
					if err != nil {
						return err
					}
				}
			} else {
				err := vm.push(condition)
				if err != nil {
					return err
				}
			}
		case code.OpSetGlobal, code.OpSetGlobalImm:
			globalIndex := code.ReadUint16(ins[ip+1:])
			ip += 2
			vm.ensureGlobalWritable(int(globalIndex))
			vm.globals[globalIndex] = vm.pop()
			if int(globalIndex) >= vm.globalsHighWater {
				vm.globalsHighWater = int(globalIndex) + 1
			}
		case code.OpGetGlobal, code.OpGetGlobalImm:
			globalIndex := code.ReadUint16(ins[ip+1:])
			ip += 2
			frame.ip = ip
			if int(globalIndex) < len(vm.globals) {
				err := vm.push(vm.globals[globalIndex])
				if err != nil {
					err = vm.PushAndReturnError(err)
					if err != nil {
						return err
					}
				}
			} else if err := vm.push(nil); err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpGetGlobalImmOrSpecial:
			globalIndex := code.ReadUint16(ins[ip+1:])
			processKeyIndex := code.ReadUint8(ins[ip+3:])
			ip += 3
			frame.ip = ip
			var err error
			if processKeyIndex != 0 && vm.safePeek().Type() == object.PROCESS_OBJ && len(ins) >= ip+1 && ins[ip+1] == byte(code.OpIndex) {
				ip += 1 // Skip over OpIndex, we are going to pop and then push the evaluated result back on the stack
				frame.ip = ip
				name := object.GetProcessKeyName(processKeyIndex)
				err = vm.executeProcessIndexExpression(vm.pop().(*object.Process), name)
			} else {
				if int(globalIndex) < len(vm.globals) {
					err = vm.push(vm.globals[globalIndex])
				} else {
					err = vm.push(nil)
				}
			}
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpList:
			numElems := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			list := vm.buildList(vm.sp-numElems, vm.sp)
			vm.sp = vm.sp - numElems
			err := vm.push(list)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpMap:
			numPairs := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			m := vm.buildMap(vm.sp-numPairs, vm.sp)
			vm.sp = vm.sp - numPairs
			err := vm.push(m)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpSet:
			numElems := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			set := vm.buildSet(vm.sp-numElems, vm.sp)
			vm.sp = vm.sp - numElems
			err := vm.push(set)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpIndex:
			index := vm.pop()
			left := vm.pop()
			if index.Type() == object.CLOSURE || index.Type() == object.BUILTIN_OBJ {
				// Method call sugar (eg. x.len()). Mark the frame so the
				// following OpCall passes the receiver as an extra argument.
				// The old implementation patched the OpCall operand byte in
				// the shared bytecode, which made bytecode unsafe to execute
				// on more than one vm at a time. Like the old code, only
				// take this path when a following OpCall exists in the
				// instruction stream, otherwise treat it as a plain index.
				if blueutil.GetNextOpCallPos(ins, ip) != -1 {
					frame.methodCallPending = true
					err := vm.push(index)
					if err != nil {
						return err
					}
					err = vm.push(left)
					if err != nil {
						return err
					}
				} else {
					err := vm.executeIndexExpression(left, index)
					if err != nil {
						err = vm.PushAndReturnError(err)
						if err != nil {
							return err
						}
					}
				}
			} else {
				err := vm.executeIndexExpression(left, index)
				if err != nil {
					err = vm.PushAndReturnError(err)
					if err != nil {
						return err
					}
				}
			}
		case code.OpCall:
			numArgs := int(code.ReadUint8(ins[ip+1:]))
			if frame.methodCallPending {
				// The callee was pushed via a method-call OpIndex, which also
				// pushed the receiver as an extra argument.
				numArgs++
				frame.methodCallPending = false
			}
			ip += 1
			frame.ip = ip
			err := vm.executeCall(numArgs)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
			frame = vm.currentFrame()
			ins = frame.Instructions()
			ip = frame.ip
		case code.OpReturnValue:
			frame.cl.Fun.ClearSpecialFunctionParameters()
			returnValue := vm.pop()
			poppedFrame := vm.popFrame()
			// Clear catch state when returning from a closure. The catch
			// context belongs to the closure's execution scope and must not
			// leak into the caller or subsequent operations.
			frame = vm.currentFrame()
			if poppedFrame != nil && frame != nil {
				frame.inCatch = false
				frame.catchError = ""
			}
			if poppedFrame != nil {
				vm.sp = poppedFrame.bp - 1
			}
			err := vm.push(returnValue)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
			if poppedFrame != nil {
				// Detach the defer list before running: callClosure
				// reuses the popped frame's slot, which would otherwise
				// clobber poppedFrame.deferFuns mid-iteration.
				deferFuns := poppedFrame.deferFuns
				poppedFrame.deferFuns = nil
				for i := len(deferFuns) - 1; i >= 0; i-- {
					err := vm.callClosure(deferFuns[i], 0)
					if err != nil {
						err = vm.PushAndReturnError(err)
						if err != nil {
							return err
						}
					}
					frame = vm.currentFrame()
				}
			}
			if frame == nil {
				// Break out if the current frame is actually empty
				// Should only ever happen with applyFunction
				return fmt.Errorf(consts.NORMAL_EXIT_ON_RETURN)
			}
			ins = frame.Instructions()
			ip = frame.ip
		case code.OpReturn:
			frame.cl.Fun.ClearSpecialFunctionParameters()
			poppedFrame := vm.popFrame()
			// Clear catch state when returning from a closure.
			frame = vm.currentFrame()
			if poppedFrame != nil && frame != nil {
				frame.inCatch = false
				frame.catchError = ""
			}
			if poppedFrame != nil {
				vm.sp = poppedFrame.bp - 1
			}
			err := vm.push(object.NULL)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
			if poppedFrame != nil {
				// Detach the defer list before running: callClosure
				// reuses the popped frame's slot, which would otherwise
				// clobber poppedFrame.deferFuns mid-iteration.
				deferFuns := poppedFrame.deferFuns
				poppedFrame.deferFuns = nil
				for i := len(deferFuns) - 1; i >= 0; i-- {
					err := vm.callClosure(deferFuns[i], 0)
					if err != nil {
						err = vm.PushAndReturnError(err)
						if err != nil {
							return err
						}
					}
					frame = vm.currentFrame()
				}
			}
			if frame == nil {
				// Break out if the current frame is actually empty
				// Should only ever happen with applyFunction
				return fmt.Errorf(consts.NORMAL_EXIT_ON_RETURN)
			}
			ins = frame.Instructions()
			ip = frame.ip
		case code.OpSetLocal, code.OpSetLocalImm:
			localIndex := code.ReadUint8(ins[ip+1:])
			ip += 1
			vm.stack[frame.bp+int(localIndex)] = vm.pop()
		case code.OpGetLocal, code.OpGetLocalImm:
			localIndex := code.ReadUint8(ins[ip+1:])
			ip += 1
			frame.ip = ip
			err := vm.push(vm.stack[frame.bp+int(localIndex)])
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpClosure:
			constIndex := code.ReadUint16(ins[ip+1:])
			numFree := code.ReadUint8(ins[ip+3:])
			ip += 3
			frame.ip = ip
			err := vm.pushClosure(int(constIndex), int(numFree))
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpGetFree, code.OpGetFreeImm:
			freeIndex := code.ReadUint8(ins[ip+1:])
			ip += 1
			frame.ip = ip
			currentClosure := frame.cl
			err := vm.push(currentClosure.Free[freeIndex])
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpGetBuiltin:
			builtinModuleIndex := code.ReadUint8(ins[ip+1:])
			builtinIndex := code.ReadUint8(ins[ip+2:])
			ip += 2
			var err error
			if builtinModuleIndex == object.BuiltinobjsModuleIndex {
				definition := object.BuiltinobjsList[builtinIndex]
				obj := definition.Builtin.Obj
				if definition.Name == "ENV" {
					obj.(*object.Map).IsEnvBuiltin = true
				}
				err = vm.push(obj)
			} else {
				definition := object.AllBuiltins[builtinModuleIndex].Builtins[builtinIndex]
				var builtin *object.Builtin
				if definition.Fun == nil {
					if builtinModuleIndex != 0 {
						modName := object.GetNameOfModuleByIndex(int(builtinModuleIndex))
						// Per-vm cache for vm bound std builtins. Inlined
						// `from http import` statements re-resolve these on
						// every call, and resolving must not rebuild (or in
						// the case of _handle_ws, re-clone) each time.
						cacheKey := modName + "/" + definition.Name
						var ok bool
						builtin, ok = vm.builtinObjs[cacheKey]
						if !ok {
							builtin = &object.Builtin{
								Name:    definition.Name,
								Fun:     GetStdBuiltinWithVm(modName, definition.Name, vm),
								HelpStr: definition.HelpStr,
								Mutates: definition.Mutates,
							}
							if vm.builtinObjs == nil {
								vm.builtinObjs = make(map[string]*object.Builtin)
							}
							vm.builtinObjs[cacheKey] = builtin
						}
					} else {
						// Per-vm builtin cache. The builtin definition is
						// shared across vms, so it must never be written
						// to here: concurrent vms would race on it.
						var ok bool
						builtin, ok = vm.builtinObjs[definition.Name]
						if !ok {
							builtin = &object.Builtin{
								Name:    definition.Name,
								Fun:     GetBuiltinFunWithVm(definition.Name, vm),
								HelpStr: definition.HelpStr,
								Mutates: definition.Mutates,
							}
							if vm.builtinObjs == nil {
								vm.builtinObjs = make(map[string]*object.Builtin)
							}
							vm.builtinObjs[definition.Name] = builtin
						}
					}
				} else {
					builtin = definition
				}
				err = vm.push(builtin)
			}
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpStringInterp:
			stringIndex := code.ReadUint16(ins[ip+1:])
			numPairs := int(code.ReadUint8(ins[ip+3:]))
			ip += 3
			frame.ip = ip
			s := vm.buildStringWithInterp(vm.sp-numPairs, vm.sp, int(stringIndex))
			vm.sp = vm.sp - numPairs - 1
			err := vm.push(s)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpIndexSet:
			index := vm.pop()
			left := vm.pop()
			right := vm.pop()
			err := vm.executeIndexSetOperator(left, index, right)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			} else {
				err := vm.push(object.NULL)
				if err != nil {
					err = vm.PushAndReturnError(err)
					if err != nil {
						return err
					}
				}
			}
		case code.OpTry:
			// Reset catch state when entering a try block. This is important
			// because inCatch/catchError are process-level flags and must be
			// clean for each new try-catch scope.
			if !frame.inCatch {
				frame.catchError = ""
			}
			frame.inTry = true
		case code.OpCatch:
			if frame.catchError == "" {
				vm.gotoCatchEnd()
			} else {
				frame.inCatch = true
			}
		case code.OpFinallyEnd:
			if frame.catchError != "" {
				return vm.prepareStackTraceAndReturnError(fmt.Errorf("%s", frame.catchError))
			}
			frame.inTry = false
			frame.inCatch = false
		case code.OpCatchEnd:
			frame.catchError = ""
			frame.inTry = false
			frame.inCatch = false
		case code.OpFinally, code.OpListCompLiteral, code.OpSetCompLiteral, code.OpMapCompLiteral:
			// Do nothing
		case code.OpExecString:
			constIndex := code.ReadUint16(ins[ip+1:])
			ip += 2
			frame.ip = ip
			execStr := vm.constants[constIndex]
			str, ok := execStr.(*object.ExecString)
			if !ok {
				return fmt.Errorf("expected ExecString, got=%T", execStr)
			}
			err := vm.push(object.ExecStringCommand(str.Value))
			if err != nil {
				return err
			}
		case code.OpEval:
			strToEval := vm.pop()
			err := vm.executeEvalOperation(strToEval)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpMatchValue:
			right := vm.pop()
			left := vm.pop()
			err := vm.push(nativeToBooleanObject(matches(left, right)))
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpMatchAny:
			err := vm.push(object.VM_IGNORE)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpDefaultArgs:
			numPairs := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			m := vm.buildDefaultArgs(vm.sp-numPairs, vm.sp)
			vm.sp = vm.sp - numPairs
			err := vm.push(m)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpSlice:
			sliceIndexes := vm.pop()
			left := vm.pop()
			err := vm.push(vm.buildSliceFrom(left, sliceIndexes))
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpStruct:
			numFields := int(code.ReadUint16(ins[ip+1:]))
			ip += 2
			frame.ip = ip
			// -1 to account for the fields held in go object
			startIndex := vm.sp - numFields - 1
			bs, err := vm.buildStruct(startIndex, vm.sp)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
			vm.sp = startIndex
			err = vm.push(bs)
			if err != nil {
				return err
			}
		case code.OpGetListIndex:
			index := int(code.ReadUint8(ins[ip+1:]))
			ip += 1
			frame.ip = ip
			list := vm.peek() // Dont pop it off the stack
			if list.Type() != object.LIST_OBJ {
				return vm.PushAndReturnError(fmt.Errorf("OpGetListIndex did not find List on top of the stack. got=%T", list))
			}
			l := list.(*object.List).Elements
			if index > len(l) {
				return vm.PushAndReturnError(fmt.Errorf("OpGetListIndex index is greater than the length of the list. index=%d, len(list)=%d", index, len(l)))
			}
			err := vm.push(l[index])
			if err != nil {
				return err
			}
		case code.OpGetMapKey:
			key := vm.peek()
			if key.Type() != object.STRING_OBJ {
				return vm.PushAndReturnError(fmt.Errorf("OpGetMapKey did not find string key on top of the stack. got=%T", key))
			}
			m := vm.peekOffset(1)
			if m.Type() != object.MAP_OBJ {
				return vm.PushAndReturnError(fmt.Errorf("OpGetMapKey did not find map on top-1 of the stack. got=%T", m))
			}
			pair, ok := m.(*object.Map).Pairs.Get(object.HashKey{Type: object.STRING_OBJ, Value: object.HashObject(key)})
			if !ok {
				return vm.PushAndReturnError(fmt.Errorf("OpGetMapKey did not find value for name: `%s` in the map", key.(*object.Stringo).Value))
			}
			err := vm.push(pair.Value)
			if err != nil {
				return err
			}
		case code.OpDefer:
			numDefers := int(code.ReadUint8(ins[ip+1:]))
			ip += 1
			frame.ip = ip
			for range numDefers {
				deferFun := vm.pop()
				if deferFun.Type() != object.CLOSURE {
					return vm.PushAndReturnError(fmt.Errorf("OpDefer did not find function on top of the stack. got=%T", deferFun))
				}
				frame.PushDeferFun(deferFun.(*object.Closure))
			}
		case code.OpSelf:
			var err error
			if p, ok := object.ProcessMap.Load(object.Pk(vm.NodeName, vm.PID)); ok {
				err = vm.push(p)
			} else {
				err = vm.push(newError("`self` error: process not found"))
			}
			if err != nil {
				return err
			}
		case code.OpSpawn:
			numArgs := int(code.ReadUint8(ins[ip+1:]))
			ip += 1
			frame.ip = ip
			var args []object.Object
			funArgIndex := 0
			listArgIndex := -1
			if numArgs == 0 {
				args = []object.Object{vm.pop()}
				funArgIndex = 0
			} else {
				args = []object.Object{vm.pop(), vm.pop()}
				funArgIndex = 1
				listArgIndex = 0
			}
			vm.executeSpawn(args, funArgIndex, listArgIndex)
		case code.OpGetFunctionParameterSpecial:
			indexParam := int(code.ReadUint8(ins[ip+1:]))
			indexList := int(code.ReadUint8(ins[ip+2:]))
			ip += 2
			frame.ip = ip
			err := vm.pushSpecialFunctionParameter(indexParam, indexList)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpGetFunctionParameterSpecial2:
			constIndex := code.ReadUint16(ins[ip+1:])
			ip += 2
			frame.ip = ip
			str, ok := vm.constants[constIndex].(*object.Stringo)
			if !ok {
				return vm.prepareStackTraceAndReturnError(fmt.Errorf("found non-string in constant for OpGetFunctionParameterSpecial2, got = %T", vm.constants[constIndex]))
			}
			err := vm.pushSpecialFunctionParameter2(str.Value)
			if err != nil {
				err = vm.PushAndReturnError(err)
				if err != nil {
					return err
				}
			}
		case code.OpSpecialIndexHelper:
			maybeJumpPos := int(code.ReadUint16(ins[ip+1:]))
			isSet := code.Opcode(ins[maybeJumpPos]) == code.OpIndexSet
			ip += 2
			// Should be the string constant of the 'indx'
			indxStr := vm.peek().(*object.Stringo)
			// Should be the the object we are trying to figure out if its being pushed
			// to a function or if its a map and we are just indexing by this
			obj1 := vm.peekOffset(1)
			if obj1.Type() != object.MAP_OBJ {
				// If its not a map, just assume we are trying to push this to a function
				// pop the index string off the stack so it doesnt interfere
				vm.pop()
			} else {
				// If it is a map, need to determine if we need to index the map, or just pass to next function
				if obj1.(*object.Map).ContainsStringoKey(indxStr) || isSet {
					// Leave the string on the stack to be used for indexing and skip loading the global
					// If its an index set operation then we always want to use the string for setting
					// when it was done via a dot call
					ip = maybeJumpPos - 1
				} else {
					// Otherwise pop off the stack and assume we are passing this map to a global function/index operation
					vm.pop()
				}
			}
		case code.OpNotInTry:
			frame.inTry = false
		case code.OpNotInCatch:
			frame.inCatch = false
		}
		if vm.framesChanged {
			vm.framesChanged = false
			frame = vm.currentFrame()
			ins = frame.Instructions()
			ip = frame.ip
		}
		if opPos != 0 {
			frame.lastInstruction = op
		}
	}
	return nil
}

func (vm *VM) prepareStackTraceAndReturnError(err error) error {
	vm.TokensForErrorTrace = []*token.Token{}
	readOpNode := func(ip int, ins code.Instructions) bool {
		if ip < 0 || ip >= len(ins) {
			return false
		}
		if code.Opcode(ins[ip]) != code.OpNode {
			return false
		}
		tokenPos := code.ReadUint16(ins[ip+1:])
		if int(tokenPos) > len(vm.tokens) {
			return false
		}
		vm.TokensForErrorTrace = append(vm.TokensForErrorTrace, vm.tokens[tokenPos])
		return true
	}
	readOpNode(vm.lastNodePos, vm.currentFrame().Instructions())
	for vm.framesIndex > 1 {
		cf := vm.currentFrame()
		vm.popFrame()
		if !readOpNode(cf.callerLastNodePos, vm.currentFrame().Instructions()) {
			break
		}
	}
	return err
}

func (vm *VM) push(o object.Object) error {
	if isError(o) {
		if vm.currentFrame().inTry || vm.currentFrame().inCatch {
			if vm.gotoNextCatchOrFinally(o.(*object.Error).Message) {
				return nil
			}
		}
		return vm.prepareStackTraceAndReturnError(fmt.Errorf("%s", o.(*object.Error).Message))
	}
	if vm.sp >= StackSize {
		return vm.prepareStackTraceAndReturnError(fmt.Errorf("stack overflow when trying to push %+#v (%T)", o, o))
	}
	vm.stack[vm.sp] = o
	vm.sp++
	return nil
}

func (vm *VM) pushNoErrorChecking(o object.Object) {
	if vm.sp >= StackSize {
		err := vm.prepareStackTraceAndReturnError(fmt.Errorf("stack overflow when trying to push %+#v (%T)", o, o))
		log.Fatalf("vm.pushNoErrorChecking: error: %s", err.Error())
	}
	vm.stack[vm.sp] = o
	vm.sp++
}

func (vm *VM) pop() object.Object {
	if vm.sp == 0 || vm.sp-1 > len(vm.stack) {
		return newError("stack pointer out of bounds")
	}
	o := vm.stack[vm.sp-1]
	vm.sp--
	return o
}

func (vm *VM) safePeek() object.Object {
	if vm.sp == 0 {
		return object.NULL
	}
	return vm.stack[vm.sp-1]
}

func (vm *VM) peek() object.Object {
	return vm.stack[vm.sp-1]
}

func (vm *VM) peekOffset(offset int) object.Object {
	return vm.stack[vm.sp-1-offset]
}

func (vm *VM) LastPoppedStackElem() object.Object {
	return vm.stack[vm.sp]
}

func (vm *VM) gotoNextCatchOrFinally(errorMessage string) bool {
	vm.currentFrame().inTry = false
	vm.currentFrame().inCatch = false
	frameIndex := vm.framesIndex - 1
	for frameIndex >= 0 {
		// Pointer into the array: isOpCatchOrFinallyFoundInFrame writes
		// frame.catchError on the stored frame.
		frame := &vm.frames[frameIndex]
		if newip, ok := vm.isOpCatchOrFinallyFoundInFrame(frame, errorMessage); ok {
			vm.framesIndex = frameIndex + 1
			vm.currentFrame().ip = newip
			vm.framesChanged = true
			return true
		}
		if frameIndex-1 < 0 {
			break
		}
		frameIndex--
	}
	return false
}

func (vm *VM) isOpCatchOrFinallyFoundInFrame(frame *Frame, errorMessage string) (int, bool) {
	if frame == nil {
		return -1, false
	}
	ins := frame.Instructions()
	for i := frame.ip - 1; i < len(ins); i++ {
		def, err := code.Lookup(ins[i])
		if err != nil {
			continue
		}
		_, read := code.ReadOperands(def, ins[i+1:])
		switch def.Name {
		case "OpCatch":
			frame.catchError = errorMessage
			vm.pushNoErrorChecking(&object.Stringo{Value: errorMessage})
			return i - 1, true
		case "OpFinally":
			frame.catchError = errorMessage
			// Don't push errorMessage for finally blocks (no variable binding)
			return i - 1, true
		}
		i += read
	}
	return -1, false
}

func (vm *VM) gotoCatchEnd() {
	frame := vm.currentFrame()
	ins := frame.Instructions()
	for i := frame.ip; i < len(ins); i++ {
		def, err := code.Lookup(ins[i])
		if err != nil {
			continue
		}
		_, read := code.ReadOperands(def, ins[i+1:])
		if def.Name == "OpCatchEnd" {
			vm.currentFrame().ip = i
			vm.framesChanged = true
			break
		}
		i += read
	}
}

func (vm *VM) executeNotOperation() error {
	operand := vm.pop()
	isTrue := isTruthy(operand)
	if isTrue {
		return vm.push(object.FALSE)
	} else {
		return vm.push(object.TRUE)
	}
}

func (vm *VM) executeNotIfNotNullOperation() error {
	if vm.peek() == object.NULL {
		return nil
	}
	return vm.executeNotOperation()
}

func (vm *VM) executeNegOperation() error {
	operand := vm.pop()
	if operand.Type() == object.INTEGER_OBJ {
		value := operand.(*object.Integer).Value
		return vm.push(intObject(-value))
	}
	if operand.Type() == object.FLOAT_OBJ {
		value := operand.(*object.Float).Value
		return vm.push(&object.Float{Value: -value})
	}
	if operand.Type() == object.BIG_INTEGER_OBJ {
		value := operand.(*object.BigInteger).Value
		return vm.push(&object.BigInteger{Value: new(big.Int).Neg(value)})
	}
	if operand.Type() == object.BIG_FLOAT_OBJ {
		value := operand.(*object.BigFloat).Value
		return vm.push(&object.BigFloat{Value: value.Neg()})
	}
	if operand.Type() == object.MAP_OBJ {
		t := object.DunderNeg
		if fn, ok := object.HasDunderFun(t, operand); ok {
			resultObj := vm.applyFunctionFast(fn, nil)
			if resultObj == nil {
				return fmt.Errorf("failed to execute -%s", operand.Inspect())
			}
			return vm.push(resultObj)
		}
	}

	return vm.push(newError("unknown operator: -%s", operand.Type()))
}

func (vm *VM) executeBitwiseNotOperation() error {
	operand := vm.pop()
	switch operand.Type() {
	case object.INTEGER_OBJ:
		value := operand.(*object.Integer).Value
		return vm.push(intObject(^value))
	case object.UINTEGER_OBJ:
		value := operand.(*object.UInteger).Value
		return vm.push(&object.UInteger{Value: ^value})
	case object.BYTES_OBJ:
		value := operand.(*object.Bytes).Value
		buf := make([]byte, len(value))
		for i, b := range value {
			buf[i] = ^b
		}
		return vm.push(&object.Bytes{Value: buf})
	case object.MAP_OBJ:
		t := object.DunderInv
		if fn, ok := object.HasDunderFun(t, operand); ok {
			resultObj := vm.applyFunctionFast(fn, nil)
			if resultObj == nil {
				return fmt.Errorf("failed to execute ~%s", operand.Inspect())
			}
			return vm.push(resultObj)
		}
		return vm.push(newError("unknown operator: ~%s", operand.Type()))
	default:
		return vm.push(newError("unknown operator: ~%s", operand.Type()))
	}
}

func (vm *VM) executeLshiftPrefixOperation() error {
	operand := vm.pop()
	switch operand.Type() {
	case object.LIST_OBJ:
		l := operand.(*object.List)
		listLen := len(l.Elements)
		if listLen == 0 {
			return vm.push(object.NULL)
		}
		e := l.Elements[0]
		if listLen == 1 {
			l.Elements = []object.Object{}
		} else {
			l.Elements = l.Elements[1:listLen]
		}
		return vm.push(e)
	default:
		return vm.push(newError("unknown operator: << %s", operand.Type()))
	}
}

func (vm *VM) executeRshiftPostfixOperation() error {
	operand := vm.pop()
	switch operand.Type() {
	case object.LIST_OBJ:
		l := operand.(*object.List)
		listLen := len(l.Elements)
		if listLen == 0 {
			return vm.push(object.NULL)
		}
		e := l.Elements[listLen-1]
		if listLen == 1 {
			l.Elements = []object.Object{}
		} else {
			l.Elements = l.Elements[0 : listLen-1]
		}
		return vm.push(e)
	default:
		return vm.push(newError("unknown operator: %s >>", operand.Type()))
	}
}

func (vm *VM) buildList(startIndex, endIndex int) object.Object {
	elements := make([]object.Object, endIndex-startIndex)
	for i := startIndex; i < endIndex; i++ {
		elements[i-startIndex] = vm.stack[i]
	}
	return &object.List{Elements: elements}
}

func (vm *VM) buildSet(startIndex, endIndex int) object.Object {
	setMap := object.NewSetElementsWithSize(endIndex - startIndex)
	for i := startIndex; i < endIndex; i++ {
		elem := vm.stack[i]
		hashKey := object.HashObject(elem)
		setMap.Set(hashKey, object.SetPair{Value: elem, Present: struct{}{}})
	}
	return &object.Set{Elements: setMap}
}

func (vm *VM) buildStruct(startIndex, endIndex int) (object.Object, error) {
	index := startIndex
	maybeFields := vm.stack[index]
	fields, ok := maybeFields.(*object.GoObj[[]string])
	if !ok {
		return nil, fmt.Errorf("compilation error: struct did not have fields in index: %d", index)
	}
	index++
	bs, err := object.NewBlueStruct(fields.Value, object.CloneSlice(vm.stack[index:endIndex]))
	if err != nil {
		return nil, err
	}
	return bs, nil
}

func (vm *VM) buildMap(startIndex, endIndex int) object.Object {
	pairs := object.NewPairsMapWithSize((endIndex - startIndex) / 2)
	for i := startIndex; i < endIndex; i += 2 {
		key := vm.stack[i]
		value := vm.stack[i+1]
		if isError(key) {
			return key
		} else if isError(value) {
			return value
		}
		// TODO: Missing some logic here from evaluator
		if ok := object.IsHashable(key); !ok {
			return newError("unusable as a map key: %s", key.Type())
		}
		hk := object.HashObject(key)
		hashed := object.HashKey{Type: key.Type(), Value: hk}

		pairs.Set(hashed, object.MapPair{Key: key, Value: value})
	}
	return &object.Map{Pairs: pairs}
}

func (vm *VM) buildDefaultArgs(startIndex, endIndex int) object.Object {
	m := make(map[string]object.Object)
	for i := startIndex; i < endIndex; i += 2 {
		key := vm.stack[i]
		value := vm.stack[i+1]
		if isError(key) {
			return key
		} else if isError(value) {
			return value
		}
		m[key.(*object.Stringo).Value] = value
	}
	return &object.DefaultArgs{Value: m}
}

func (vm *VM) buildStringWithInterp(startIndex, endIndex, stringIndex int) object.Object {
	str := vm.constants[stringIndex]
	s, ok := str.(*object.Stringo)
	if !ok {
		return newError("string interpolation failed with non-string `%s`", str.Inspect())
	}
	newStr := s.Value
	for i := startIndex; i < endIndex; i += 2 {
		exp := vm.stack[i]
		orig := vm.stack[i+1]
		newStr = strings.Replace(newStr, orig.Inspect(), vm.CustomInspect(exp), 1)
	}
	return object.NewString(newStr)
}

func (vm *VM) executeIndexExpression(left, indx object.Object) error {
	switch {
	case left.Type() == object.LIST_OBJ:
		return vm.executeListIndexExpression(left, indx)
	case left.Type() == object.SET_OBJ:
		return vm.executeSetIndexExpression(left, indx)
	case left.Type() == object.MAP_OBJ:
		return vm.executeMapIndexExpression(left, indx)
	case left.Type() == object.STRING_OBJ:
		return vm.executeStringIndexExpression(left, indx)
	// case left.Type() == object.MODULE_OBJ:
	// 	return e.evalModuleIndexExpression(left, indx)
	case left.Type() == object.PROCESS_OBJ && indx.Type() == object.STRING_OBJ:
		return vm.executeProcessIndexExpression(left.(*object.Process), indx.(*object.Stringo).Value)
	case left.Type() == object.GO_OBJ && indx.Type() == object.STRING_OBJ:
		return vm.executeGoObjIndexExpression(left, indx.(*object.Stringo).Value)
	case left.Type() == object.BLUE_STRUCT_OBJ && indx.Type() == object.STRING_OBJ:
		return vm.executeBlueIndexGetExpression(left.(*object.BlueStruct), indx.(*object.Stringo).Value)
	default:
		return vm.push(newError("index operator not supported: %s.%s (%s.%s)", left.Type(), indx.Type(), left.Inspect(), indx.Inspect()))
	}
}

// Set Frames[0] and Frames[1] to the same frame from callClosureFastFrame
// so that when calling Run on blue function via applyFunctionFast we can
// return the top of stack value internally and revert state
func (vm *VM) executeCallFastFrame(numArgs int) error {
	callee := vm.stack[vm.sp-1-numArgs]
	if closure, ok := callee.(*object.Closure); ok {
		return vm.callClosureFastFrame(closure, numArgs)
	}
	return nil
}

func (vm *VM) executeCall(numArgs int) error {
	callee := vm.stack[vm.sp-1-numArgs]
	switch callee := callee.(type) {
	case *object.Closure:
		return vm.callClosure(callee, numArgs)
	case *object.Builtin:
		return vm.callBuiltin(callee, numArgs)
	default:
		return vm.prepareStackTraceAndReturnError(fmt.Errorf("calling non-closure and non-builtin. got=%s", callee.Type()))
	}
}

func (vm *VM) callClosureFastFrame(cl *object.Closure, numArgs int) error {
	newArgCount, err := vm.interweaveArgsForCall(cl.Fun, numArgs)
	if err != nil {
		return err
	}

	// CurrentFrame looks at frameIndex-1; replace that slot in place.
	frame := vm.newCallFrameReplaceTop(cl, vm.sp-newArgCount)
	frame.callerLastNodePos = vm.lastNodePos
	if cf := vm.currentFrame(); cf != nil {
		frame.inTry = cf.inTry
		frame.inCatch = cf.inCatch
	}
	vm.sp = frame.bp + cl.Fun.NumLocals
	return nil
}

func (vm *VM) callClosure(cl *object.Closure, numArgs int) error {
	newArgCount, err := vm.interweaveArgsForCall(cl.Fun, numArgs)
	if err != nil {
		return err
	}

	frame := vm.newCallFrame(cl, vm.sp-newArgCount)
	frame.callerLastNodePos = vm.lastNodePos
	if cf := vm.currentFrame(); cf != nil {
		frame.inTry = cf.inTry
		frame.inCatch = cf.inCatch
		frame.catchError = cf.catchError
	}
	// CurrentFrame looks at frameIndex-1; the new frame was initialized in
	// the next slot so just advance the index (pushFrame would copy onto
	// itself).
	vm.framesIndex++
	vm.sp = frame.bp + cl.Fun.NumLocals
	return nil
}

func (vm *VM) interweaveArgsForCall(cl *object.CompiledFunction, numArgs int) (int, error) {
	// Fast path: exact argument count and the function has no default
	// parameters, so the arguments are already in their final positions on
	// the stack. Avoids a slice allocation and re-push per call.
	if cl.NumDefaultParams == 0 && numArgs == cl.NumParameters {
		if numArgs == 0 || vm.stack[vm.sp-1].Type() != object.DEFAULT_ARGS_OBJ {
			return numArgs, nil
		}
	}
	currentArgsOnStack := vm.stack[vm.sp-numArgs : vm.sp]
	vm.sp -= numArgs
	if len(currentArgsOnStack) > cl.NumParameters {
		return 0, fmt.Errorf("wrong number of arguments: want=%d, got=%d", cl.NumParameters, numArgs)
	}
	realNumArg := numArgs
	var defaultArgs map[string]object.Object = nil
	if len(currentArgsOnStack) != 0 {
		lastArg := currentArgsOnStack[len(currentArgsOnStack)-1]
		if da, ok := lastArg.(*object.DefaultArgs); ok {
			defaultArgs = da.Value
			realNumArg--
			currentArgsOnStack = currentArgsOnStack[:len(currentArgsOnStack)-1]
		}
	}
	currentArgOnStackIndex := 0
	args := make([]object.Object, 0, cl.NumParameters)
	potentialArgCount := realNumArg + cl.NumDefaultParams
	potentialArgToSwap := struct {
		paramIndex, argOnStackIndex int
	}{
		paramIndex:      -1,
		argOnStackIndex: -1,
	}
	for i := range cl.NumParameters {
		if realNumArg == cl.NumParameters {
			args = append(args, currentArgsOnStack[currentArgOnStackIndex])
			currentArgOnStackIndex++
			continue
		} else if defaultArgs != nil {
			if defaultArg, ok := defaultArgs[cl.Parameters[i]]; ok {
				args = append(args, defaultArg)
				continue
			}
		}
		useParamCond := (potentialArgCount == cl.NumParameters && cl.ParameterHasDefault[i]) ||
			(potentialArgCount > cl.NumParameters && currentArgOnStackIndex == len(currentArgsOnStack) && cl.ParameterHasDefault[i])
		if useParamCond {
			args = append(args, object.USE_PARAM_STR_OBJ)
		} else if potentialArgCount == cl.NumParameters && currentArgOnStackIndex < len(currentArgsOnStack) {
			args = append(args, currentArgsOnStack[currentArgOnStackIndex])
			currentArgOnStackIndex++
		} else if potentialArgCount > cl.NumParameters && currentArgOnStackIndex < len(currentArgsOnStack) {
			args = append(args, currentArgsOnStack[currentArgOnStackIndex])
			currentArgOnStackIndex++
			if cl.ParameterHasDefault[i] {
				potentialArgToSwap.argOnStackIndex = currentArgOnStackIndex - 1
				potentialArgToSwap.paramIndex = i
			}
		} else if realNumArg < cl.NumDefaultParams && potentialArgCount > cl.NumParameters && defaultArgs == nil && !cl.ParameterHasDefault[i] && potentialArgToSwap.argOnStackIndex != -1 {
			// Append the arg from the prior position that had a default parameter (and this one doesnt)
			args = append(args, currentArgsOnStack[potentialArgToSwap.argOnStackIndex])
			// Replace the prior position with the USE_PARAM object so that it will be used
			args[potentialArgToSwap.argOnStackIndex] = object.USE_PARAM_STR_OBJ
		}
	}
	argCountAfterWeave := len(args)
	if argCountAfterWeave != cl.NumParameters {
		return 0, fmt.Errorf("wrong number of arguments: want=%d, got=%d", cl.NumParameters, numArgs)
	}
	for _, arg := range args {
		err := vm.push(arg)
		if err != nil {
			return 0, err
		}
	}
	return argCountAfterWeave, nil
}

func (vm *VM) pushClosure(constIndex, numFree int) error {
	constant := vm.constants[constIndex]
	function, ok := constant.(*object.CompiledFunction)
	if !ok {
		return fmt.Errorf("not a function: %+v", constant)
	}
	var free []object.Object
	if numFree > 0 {
		free = make([]object.Object, numFree)
		for i := range numFree {
			free[i] = vm.stack[vm.sp-numFree+i]
		}
		vm.sp = vm.sp - numFree
	}
	closure := &object.Closure{Fun: function, Free: free}
	return vm.push(closure)
}

func (vm *VM) callBuiltin(builtin *object.Builtin, numArgs int) error {
	args := vm.stack[vm.sp-numArgs : vm.sp]
	result := builtin.Fun(args...)
	vm.sp = vm.sp - numArgs - 1
	return vm.push(result)
}

// EvalHook, when non-nil, evaluates blue source strings at runtime (the
// `eval` keyword plus builtins like `to_num`/`load` that can evaluate a
// string). Full builds (the main `blue` binary, the wasm entrypoint)
// install the real lexer/parser/compiler implementation from their own glue
// code; minimal VM-only builds leave it nil and evaluation attempts return
// a clear runtime error instead.
var EvalHook func(src string) object.Object

// vmStr evaluates a source string through the installed EvalHook.
func vmStr(s string) object.Object {
	if EvalHook == nil {
		return newError("`eval` is not available in this build: it requires the full blue toolchain (rebuild the standard binary or run via the full blue executable)")
	}
	return EvalHook(s)
}

func (vm *VM) executeSpawn(args []object.Object, funArgIndex, listArgIndex int) {
	if args[funArgIndex].Type() != object.CLOSURE {
		_ = vm.push(newError("`spawn` error: expected function got = %s", args[funArgIndex].Type()))
		return
	}
	if args[listArgIndex].Type() != object.LIST_OBJ {
		_ = vm.push(newError("`spawn` error: expected list got = %s", args[listArgIndex].Type()))
		return
	}
	fun := args[funArgIndex].(*object.Closure)
	pid := object.PidCount.Add(1)
	process := &object.Process{
		Id: pid,
		// TODO: Eventually update to non-buffered and update send and recv as needed
		Ch: make(chan object.Object, 1),

		NodeName: vm.NodeName,
	}
	object.ProcessMap.Store(object.Pk(vm.NodeName, pid), process)
	clonedVm := vm.Clone(pid)
	// Dont clone args list so if processes are sent through then they will be usable by the process (channel must not be "cloned")
	go spawnFunction(clonedVm, vm.NodeName, fun.Clone().(*object.Closure), args[listArgIndex].(*object.List))
	_ = vm.push(process)
}

func spawnFunction(vm *VM, nodeName string, fun *object.Closure, arg1 object.Object) {
	elems := arg1.(*object.List).Elements
	newObj := vm.applyFunctionFastWithMultipleArgs(fun, elems)
	if isError(newObj) {
		// err := newObj.(*object.Error)
		// var buf bytes.Buffer
		// buf.WriteString(err.Message)
		// buf.WriteByte('\n')
		// for newE.ErrorTokens.Len() > 0 {
		// 	tok := newE.ErrorTokens.PopBack()
		// 	fmt.Fprintf(&buf, "%s\n", lexer.GetErrorLineMessage(tok))
		// }
		fmt.Printf("%s%s\n", consts.PROCESS_ERROR_PREFIX, newObj.(*object.Error).Message)
	}
	// Delete from concurrent map and close channel (not 100% sure its necessary)
	if process, ok := object.ProcessMap.LoadAndDelete(object.Pk(nodeName, vm.PID)); ok {
		close(process.Ch)
	}
}
