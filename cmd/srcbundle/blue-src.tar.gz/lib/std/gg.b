## `gg` is the module that contains functions needed to
## run the games graphics library (Raylib)

val __init_window = _init_window;
val __window_should_close = _window_should_close;
val __close_window = _close_window;
val __is_window_ready = _is_window_ready;
val __is_window_fullscreen = _is_window_fullscreen;
val __is_window_hidden = _is_window_hidden;
val __is_window_maximized = _is_window_maximized;
val __is_window_minimized = _is_window_minimized;
val __is_window_focused = _is_window_focused;
val __is_window_resized = _is_window_resized;
val __toggle_window_fullscreen = _toggle_window_fullscreen;
val __maximize_window = _maximize_window;
val __minimize_window = _minimize_window;
val __restore_window = _restore_window;
val __set_window_icon = _set_window_icon;
val __set_window_title = _set_window_title;
val __set_window_position = _set_window_position;
val __set_window_monitor = _set_window_monitor;
val __set_window_min_size = _set_window_min_size;
val __set_window_size = _set_window_size;
val __set_window_opacity = _set_window_opacity;
val __set_window_focused = _set_window_focused;
val get_screen_width = _get_screen_width;
val get_screen_height = _get_screen_height;
val __get_monitor_count = _get_monitor_count;
val __get_current_monitor = _get_current_monitor;
val __get_monitor_position = _get_monitor_position;
val __get_monitor_width = _get_monitor_width;
val __get_monitor_height = _get_monitor_height;
val __get_monitor_physical_width = _get_monitor_physical_width;
val __get_monitor_physical_height = _get_monitor_physical_height;
val __get_monitor_refresh_rate = _get_monitor_refresh_rate;
val __get_monitor_name = _get_monitor_name;

val __get_clipboard_text = _get_clipboard_text;
val __set_clipboard_text = _set_clipboard_text;

val __show_cursor = _show_cursor;
val __hide_cursor = _hide_cursor;
val __is_cursor_hidden = _is_cursor_hidden;
val __enable_cursor = _enable_cursor;
val __disable_cursor = _disable_cursor;
val __is_cursor_on_screen = _is_cursor_on_screen;

val __clear_background = _clear_background;
val color = _color_map();
val begin_drawing = _begin_drawing;
val end_drawing = _end_drawing;
val set_target_fps = _set_target_fps;
val get_fps = _get_fps;
val get_frame_time = _get_frame_time;
val get_time = _get_time;

val unload = _unload;
val __draw_text = _draw_text;
val __draw_texture = _draw_texture;
val load_texture = _load_texture;
val __n_patch_layout_map = _n_patch_layout_map;
val __new_n_patch_info = _new_n_patch_info;

# Audio/Music/Sound
val init_audio_device = _init_audio_device;
val close_audio_device = _close_audio_device;
val load_music = _load_music;
val update_music = _update_music;
val play_music = _play_music;
val stop_music = _stop_music;
val pause_music = _pause_music;
val resume_music = _resume_music;
val load_sound = _load_sound;
val play_sound = _play_sound;
val stop_sound = _stop_sound;
val resume_sound = _resume_sound;
val pause_sound = _pause_sound;

# Image
val __load_image = _load_image;
val __is_image_ready = _is_image_ready;
val __image_export = _image_export;
val __image_gen_cellular = _image_gen_cellular;
val __image_gen_checked = _image_gen_checked;
val __image_gen_color = _image_gen_color;
val __image_gen_gradient_h = _image_gen_gradient_h;
val __image_gen_gradient_v = _image_gen_gradient_v;
val __image_gen_gradient_radial = _image_gen_gradient_radial;
val __image_gen_perlin_noise = _image_gen_perlin_noise;
val __image_gen_text = _image_gen_text;
val __image_gen_white_noise = _image_gen_white_noise;
val __image_copy = _image_copy;
val __image_text = _image_text;
val __image_format = _image_format;
val __image_to_pot = _image_to_pot;
val __image_crop = _image_crop;
val __image_alpha_crop = _image_alpha_crop;
val __image_alpha_clear = _image_alpha_clear;
val __image_alpha_mask = _image_alpha_mask;
val __image_alpha_premultiply = _image_alpha_premultiply;
val __image_blur_gaussian = _image_blur_gaussian;
val __image_resize = _image_resize;
val __image_resize_nn = _image_resize_nn;
val __image_resize_canvas = _image_resize_canvas;
val __image_mipmaps = _image_mipmaps;
val __image_dither = _image_dither;
val __image_flip_vertical = _image_flip_vertical;
val __image_flip_horizontal = _image_flip_horizontal;
val __image_rotate_cw = _image_rotate_cw;
val __image_rotate_ccw = _image_rotate_ccw;
val __image_color_tint = _image_color_tint;
val __image_color_invert = _image_color_invert;
val __image_color_grayscale = _image_color_grayscale;
val __image_color_contrast = _image_color_contrast;
val __image_color_brightness = _image_color_brightness;
val __image_color_replace = _image_color_replace;
val __load_image_colors = _load_image_colors;
val __get_image_color = _get_image_color;
val __image_clear_background = _image_clear_background;
val __image_draw_pixel = _image_draw_pixel;
val __image_draw_pixel_v = _image_draw_pixel_v;
val __image_draw_line = _image_draw_line;
val __image_draw_line_v = _image_draw_line_v;
val __image_draw_circle = _image_draw_circle;
val __image_draw_circle_v = _image_draw_circle_v;
val __image_draw_circle_lines = _image_draw_circle_lines;
val __image_draw_circle_lines_v = _image_draw_circle_lines_v;
val __image_draw_rectangle = _image_draw_rectangle;
val __image_draw_rectangle_v = _image_draw_rectangle_v;
val __image_draw_rectangle_rec = _image_draw_rectangle_rec;
val __image_draw_rectangle_lines = _image_draw_rectangle_lines;
val __image_draw_image = _image_draw_image;
val __image_draw_text = _image_draw_text;
val __image_draw_text_ex = _image_draw_text_ex;

val set_exit_key = _set_exit_key;
val is_key_up = _is_key_up;
val is_key_down = _is_key_down;
val is_key_pressed = _is_key_pressed;
val is_key_released = _is_key_released;

val __is_mouse_button_pressed = _is_mouse_button_pressed;
val __is_mouse_button_down = _is_mouse_button_down;
val __is_mouse_button_released = _is_mouse_button_released;
val __is_mouse_button_up = _is_mouse_button_up;
val __get_mouse_x = _get_mouse_x;
val __get_mouse_y = _get_mouse_y;
val __get_mouse_position = _get_mouse_position;
val __get_mouse_delta = _get_mouse_delta;
val __set_mouse_position = _set_mouse_position;
val __set_mouse_offset = _set_mouse_offset;
val __set_mouse_scale = _set_mouse_scale;
val __get_mouse_wheel_move = _get_mouse_wheel_move;
val __get_mouse_wheel_move_v = _get_mouse_wheel_move_v;
val __set_mouse_cursor = _set_mouse_cursor;

val rectangle = _rectangle;
val vector2 = _vector2;
val vector3 = _vector3;
val vector4 = _vector4;
val ray = _ray;
val __camera2d = _camera2d;
val __camera3d = _camera3d;
val matrix = _matrix;

val __begin_mode2d = _begin_mode2d;
val end_mode2d = _end_mode2d;
val __begin_mode3d = _begin_mode3d;
val end_mode3d = _end_mode3d;

val __draw_pixel = _draw_pixel;
val __draw_line = _draw_line;
val __draw_line_strip = _draw_line_strip;
val __draw_line_bezier = _draw_line_bezier;
val __draw_circle = _draw_circle;
val __draw_circle_sector = _draw_circle_sector;
val __draw_circle_lines = _draw_circle_lines;
val __draw_rectangle = _draw_rectangle;
val __draw_rectangle_gradient = _draw_rectangle_gradient;
val __draw_rectangle_lines = _draw_rectangle_lines;
val __draw_rectangle_rounded = _draw_rectangle_rounded;
val __draw_rectangle_rounded_lines = _draw_rectangle_rounded_lines;
val __draw_triangle = _draw_triangle;
val __draw_triangle_fan = _draw_triangle_fan;
val __draw_triangle_strip = _draw_triangle_strip;
val __draw_poly = _draw_poly;

val __draw_line_3d = _draw_line_3d;
val __draw_point_3d = _draw_point_3d;
val __draw_circle_3d = _draw_circle_3d;
val __draw_cube_wires = _draw_cube_wires;
val __draw_cube = _draw_cube;
val __draw_sphere_wires = _draw_sphere_wires;
val __draw_sphere = _draw_sphere;
val __draw_cylinder_wires = _draw_cylinder_wires;
val __draw_cylinder = _draw_cylinder;
val __draw_capsule_wires = _draw_capsule_wires;
val __draw_capsule = _draw_capsule;
val __draw_plane = _draw_plane;
val __draw_ray = _draw_ray;
val __draw_grid = _draw_grid;
val __load_model = _load_model;
val __is_model_ready = _is_model_ready;
val get_bounding_box = _get_bounding_box;
val __draw_model = _draw_model;
val __draw_bounding_box = _draw_bounding_box;
val __draw_billboard = _draw_billboard;
val __draw_mesh = _draw_mesh;
val __upload_mesh = _upload_mesh;
val __gen_mesh_poly = _gen_mesh_poly;
val __gen_mesh_plane = _gen_mesh_plane;
val __gen_mesh_cube = _gen_mesh_cube;
val __gen_mesh_sphere = _gen_mesh_sphere;
val __gen_mesh_hemi_sphere = _gen_mesh_hemi_sphere;
val __gen_mesh_cylinder = _gen_mesh_cylinder;
val __gen_mesh_cone = _gen_mesh_cone;
val __gen_mesh_torus = _gen_mesh_torus;
val __gen_mesh_knot = _gen_mesh_knot;
val __gen_mesh_heightmap = _gen_mesh_heightmap;
val __gen_mesh_cubicmap = _gen_mesh_cubicmap;
val __export_mesh = _export_mesh;
val __load_materials = _load_materials;
val __load_material_default = _load_material_default;
val __is_material_ready = _is_material_ready;
val __set_material_texture = _set_material_texture;
val __set_model_mesh_material = _set_model_mesh_material;
val __load_model_animations = _load_model_animations;
val __update_model_animation = _update_model_animation;
val __is_model_animation_valid = _is_model_animation_valid;

val check_collision = _check_collision;
val get_collision = _get_collision;

# Drawing
val draw = {
    'pixel': __draw_pixel,
    'line': __draw_line,
    'line_strip': __draw_line_strip,
    'line_bezier': __draw_line_bezier,
    'circle': __draw_circle,
    'circle_sector': fun(a,b,c,d,e,f,with_lines=false) {
        __draw_circle_sector(a,b,c,d,e,f,with_lines);
    },
    'circle_lines': __draw_circle_lines,
    'rectangle': __draw_rectangle,
    'rectangle_gradient': fun(a,b,c,d,e,f=null,is_vertical=true) {
        __draw_rectangle_gradient(a,b,c,d,e,f,is_vertical);
    },
    'rectangle_lines': __draw_rectangle_lines,
    'rectangle_rounded': __draw_rectangle_rounded,
    'rectangle_rounded_lines': __draw_rectangle_rounded_lines,
    'triangle': fun(a,b,c,d,with_lines=false) {
        __draw_triangle(a,b,c,d,with_lines)
    },
    'triangle_fan': __draw_triangle_fan,
    'triangle_strip': __draw_triangle_strip,
    'poly': fun(a,b,c,d,e,f=null,with_lines=false) {
        __draw_poly(a,b,c,d,e,f,with_lines)
    },
}

# 3D Drawing functions
val draw3d = {
    'line': __draw_line_3d,
    'point': __draw_point_3d,
    'circle': __draw_circle_3d,
    'cube': fun(a,b,c,d=null,e=null,with_wires=false) {
        if with_wires {
            __draw_cube_wires(a,b,c,d,e)
        } else {
            __draw_cube(a,b,c,d,e)
        }
    },
    'sphere': fun(a,b,c,d=null,e=null,with_wires=false) {
        if with_wires {
            __draw_sphere_wires(a,b,c,d,e)
        } else {
            __draw_sphere(a,b,c,d,e)
        }
    },
    'cylinder': fun(a,b,c,d,e,f,with_wires=false) {
        if with_wires {
            __draw_cylinder_wires(a,b,c,d,e,f)
        } else {
            __draw_cylinder(a,b,c,d,e,f)
        }
    },
    'capsule': fun(a,b,c,d,e,f,with_wires=false) {
        if with_wires {
            __draw_capsule_wires(a,b,c,d,e,f)
        } else {
            __draw_capsule(a,b,c,d,e,f)
        }
    },
    'plane': __draw_plane,
    'ray': __draw_ray,
    'grid': __draw_grid,
    'model': fun(a,b,c,d,e=null,f=null,with_wires=false) {
        __draw_model(a,b,c,d,e,f,with_wires)
    },
    'bounding_box': __draw_bounding_box,
    'billboard': __draw_billboard,
    'mesh': __draw_mesh,
}

val mesh = {
    'gen': {
        'poly': __gen_mesh_poly,
        'plane': __gen_mesh_plane,
        'cube': __gen_mesh_cube,
        'sphere': __gen_mesh_sphere,
        'hemi_sphere': __gen_mesh_hemi_sphere,
        'cylinder': __gen_mesh_cylinder,
        'cone': __gen_mesh_cone,
        'torus': __gen_mesh_torus,
        'knot': __gen_mesh_knot,
        'heightmap': __gen_mesh_heightmap,
        'cubicmap': __gen_mesh_cubicmap,
    },
    'export': __export_mesh,
    'upload': __upload_mesh,
};

val material = {
    'load': __load_materials,
    'load_default': __load_material_default,
    'is_ready': __is_material_ready,
    'set_texture': __set_material_texture,
};

val model = {
    'load': __load_model,
    'is_ready': __is_model_ready,
    'load_animations': __load_model_animations,
    'update_animation': __update_model_animation,
    'is_animation_valid': __is_model_animation_valid,
    'set_mesh_material': __set_model_mesh_material,
};

val image = {
    'gen': {
        'cellular': __image_gen_cellular,
        'checked': __image_gen_checked,
        'color': __image_gen_color,
        'gradient_h': __image_gen_gradient_h,
        'gradient_v': __image_gen_gradient_v,
        'gradient_radial': __image_gen_gradient_radial,
        'perlin_noise': __image_gen_perlin_noise,
        'text': __image_gen_text,
        'white_noise': __image_gen_white_noise,
    },
    'text': __image_text,
    'pixel_format': _pixel_format_map(),
};

val n_patch_info = {
    'new': __new_n_patch_info,
    'layout': __n_patch_layout_map(),
};

# Input Constants

val Key = {
    # Keyboard Function Keys
    'Space': 32,
    'Escape': 256,
    'Enter': 257,
    'Tab': 258,
    'Backspace': 259,
    'Insert': 260,
    'Delete': 261,
    'Right': 262,
    'Left': 263,
    'Down': 264,
    'Up': 265,
    'PageUp': 266,
    'PageDown': 267,
    'Home': 268,
    'End': 269,
    'CapsLock': 280,
    'ScrollLock': 281,
    'NumLock': 282,
    'PrintScreen': 283,
    'Pause': 284,
    'F1': 290,
    'F2': 291,
    'F3': 292,
    'F4': 293,
    'F5': 294,
    'F6': 295,
    'F7': 296,
    'F8': 297,
    'F9': 298,
    'F10': 299,
    'F11': 300,
    'F12': 301,
    'LeftShift': 340,
    'LeftControl': 341,
    'LeftAlt': 342,
    'LeftSuper': 343,
    'RightShift': 344,
    'RightControl': 345,
    'RightAlt': 346,
    'RightSuper': 347,
    'KbMenu': 348,
    'LeftBracket': 91,
    'BackSlash': 92,
    'RightBracket': 93,
    'Grave': 96,

    # Keyboard Number Pad Keys
    'Kp0': 320,
    'Kp1': 321,
    'Kp2': 322,
    'Kp3': 323,
    'Kp4': 324,
    'Kp5': 325,
    'Kp6': 326,
    'Kp7': 327,
    'Kp8': 328,
    'Kp9': 329,
    'KpDecimal': 330,
    'KpDivide': 331,
    'KpMultiply': 332,
    'KpSubtract': 333,
    'KpAdd': 334,
    'KpEnter': 335,
    'KpEqual': 336,

    # Keyboard Alpha Numeric Keys
    'Apostrophe': 39,
    'Comma': 44,
    'Minus': 45,
    'Period': 46,
    'Slash': 47,
    'Zero': 48,
    'One': 49,
    'Two': 50,
    'Three': 51,
    'Four': 52,
    'Five': 53,
    'Six': 54,
    'Seven': 55,
    'Eight': 56,
    'Nine': 57,
    'Semicolon': 59,
    'Equal': 61,
    'A': 65,
    'B': 66,
    'C': 67,
    'D': 68,
    'E': 69,
    'F': 70,
    'G': 71,
    'H': 72,
    'I': 73,
    'J': 74,
    'K': 75,
    'L': 76,
    'M': 77,
    'N': 78,
    'O': 79,
    'P': 80,
    'Q': 81,
    'R': 82,
    'S': 83,
    'T': 84,
    'U': 85,
    'V': 86,
    'W': 87,
    'X': 88,
    'Y': 89,
    'Z': 90,

    # Android keys
    'Back': 4,
    'Menu': 82,
    'VolumeUp': 24,
    'VolumeDown': 25,
};

val mouse = {
    'button': {
        'LeftButton': 0,
        'Left': 0,
        'RightButton': 1,
        'Right': 1,
        'MiddleButton': 2,
        'Middle': 2,
        'SideButton': 3,
        'Side': 3,
        'ExtraButton': 4,
        'Extra': 4,
        'ForwardButton': 5,
        'Forward': 5,
        'BackButton': 6,
        'Back': 6,
    },
    'is_button_pressed': __is_mouse_button_pressed,
    'is_button_released': __is_mouse_button_released,
    'is_button_down': __is_mouse_button_down,
    'is_button_up': __is_mouse_button_up,
    'get_x': __get_mouse_x,
    'get_y': __get_mouse_y,
    'get_position': __get_mouse_position,
    'get_delta': __get_mouse_delta,
    'set_position': __set_mouse_position,
    'set_offset': __set_mouse_offset,
    'set_scale': __set_mouse_scale,
    'get_wheel_move': fun(as_vector=false) {
        if as_vector {
            return __get_mouse_wheel_move_v;
        }
        return __get_mouse_wheel_move;
    },
    'set_cursor': __set_mouse_cursor,
};

# Touch points registered
val MaxTouchPoints = 2;

val Gamepad = {
    # Gamepad Number
    'Player1': 0,
    'Player2': 1,
    'Player3': 2,
    'Player4': 3,

    # Gamepad Buttons/Axis

    # PS3 USB Controller Buttons
    'Ps3ButtonTriangle': 0,
    'Ps3ButtonCircle': 1,
    'Ps3ButtonCross': 2,
    'Ps3ButtonSquare': 3,
    'Ps3ButtonL1': 6,
    'Ps3ButtonR1': 7,
    'Ps3ButtonL2': 4,
    'Ps3ButtonR2': 5,
    'Ps3ButtonStart': 8,
    'Ps3ButtonSelect': 9,
    'Ps3ButtonUp': 24,
    'Ps3ButtonRight': 25,
    'Ps3ButtonDown': 26,
    'Ps3ButtonLeft': 27,
    'Ps3ButtonPs': 12,

    # PS3 USB Controller Axis
    'Ps3AxisLeftX': 0,
    'Ps3AxisLeftY': 1,
    'Ps3AxisRightX': 2,
    'Ps3AxisRightY': 5,
    # [1..-1] (pressure-level)
    'Ps3AxisL2': 3,
    # [1..-1] (pressure-level)
    'Ps3AxisR2': 4,

    # Xbox360 USB Controller Buttons
    'XboxButtonA': 0,
    'XboxButtonB': 1,
    'XboxButtonX': 2,
    'XboxButtonY': 3,
    'XboxButtonLb': 4,
    'XboxButtonRb': 5,
    'XboxButtonSelect': 6,
    'XboxButtonStart': 7,
    'XboxButtonUp': 10,
    'XboxButtonRight': 11,
    'XboxButtonDown': 12,
    'XboxButtonLeft': 13,
    'XboxButtonHome': 8,

    # Android Gamepad Controller (SNES CLASSIC)
    'AndroidDpadUp': 19,
    'AndroidDpadDown': 20,
    'AndroidDpadLeft': 21,
    'AndroidDpadRight': 22,
    'AndroidDpadCenter': 23,

    'AndroidButtonA': 96,
    'AndroidButtonB': 97,
    'AndroidButtonC': 98,
    'AndroidButtonX': 99,
    'AndroidButtonY': 100,
    'AndroidButtonZ': 101,
    'AndroidButtonL1': 102,
    'AndroidButtonR1': 103,
    'AndroidButtonL2': 104,
    'AndroidButtonR2': 105,

    # Xbox360 USB Controller Axis
    # [-1..1] (left->right)
    'XboxAxisLeftX': 0,
    # [1..-1] (up->down)
    'XboxAxisLeftY': 1,
    # [-1..1] (left->right)
    'XboxAxisRightX': 2,
    # [1..-1] (up->down)
    'XboxAxisRightY': 3,
    # [-1..1] (pressure-level)
    'XboxAxisLt': 4,
    # [-1..1] (pressure-level)
    'XboxAxisRt': 5,
};

val monitor = {
    'get_count': __get_monitor_count,
    'get_current': __get_current_monitor,
    'get_position': __get_monitor_position,
    'get_width': __get_monitor_width,
    'get_height': __get_monitor_height,
    'get_physical_width': __get_monitor_physical_width,
    'get_physical_height': __get_monitor_physical_height,
    'get_monitor_refresh_rate': __get_monitor_refresh_rate,
    'get_name': __get_monitor_name
};

val clipboard = {
    'get_text': __get_clipboard_text,
    'set_text': __set_clipboard_text
};

val cursor = {
    'show': __show_cursor,
    'hide': __hide_cursor,
    'is_hidden': __is_cursor_hidden,
    'enable': __enable_cursor,
    'disable': __disable_cursor,
    'is_on_screen': __is_cursor_on_screen
};

# GG Objects

fun Rectangle(x=0.0, y=0.0, width=0.0, height=0.0) {
    ##std:this,rectangle
    ## `Rectangle` is an object constructor that represents the GO_OBJ for rectangles
    ##
    ## the object can be modified using the x,y,width,height variables and the GO_OBJ
    ## can be retrieved with this.obj()
    ##
    ## Rectangle(x: float=0.0, y: float=0.0, width: float=0.0, height: float=0.0) ->
    ## {'x':float,'y':float,'width':float,'height':float,'obj':|this|=>GO_OBJ[rl.Rectangle]}
    var this = {
        'x': x,
        'y': y,
        'width': width,
        'height': height,
    };
    this.obj = fun() {
        return rectangle(float(this['x']), float(this['y']), float(this['width']), float(this['height']));
    };
    this.draw = fun(c=color.red) {
        __draw_rectangle(int(this.x), int(this.y), int(this.width), int(this.height), c);
    };
    this.check_collision = fun(rec) {
        if ('obj' notin rec) {
            return error("rec must have obj() function on its map");
        }
        return check_collision(this.obj(), rec.obj());
    };
    return this;
}

fun Vector(x=0.0, y=0.0, z=null, w=null) {
    ##std:this,vector2,vector3,vector4
    ## `Vector` is an object constructor that represents the GO_OBJ for a 2, 3, or 4 Point Vector
    ## currently there is no way to edit it so any vec will just need to be recreated with .obj()
    ##
    ## Vector() -> will return a 2 point vector
    ## Vector(z=0.0) -> will return a 3 point vector
    ## Vector(w=0.0) -> returns an error (invalid args [needs a z as well])
    ##
    ## Vector(x: float=0.0, y: float=0.0, z: float=null, w: float=null)
    ##     -> {'x':float,'y':float,'obj':|this|=>GO_OBJ[rl.Vector2]}
    ##      | {'x':float,'y':float,'z':float,'obj':|this|=>GO_OBJ[rl.Vector3]}
    ##      | {'x':float,'y':float,'z':float,'w':float,'obj':|this|=>GO_OBJ[rl.Vector4]}
    var this = {
        'x': float(x),
        'y': float(y),
    };
    if (z == null && w == null) {
        this.obj = fun() {
            return vector2(float(this['x']), float(this['y']))
        };
    } else if (z != null && w == null) {
        this['z'] = float(z);
        this.obj = fun() {
            return vector3(float(this['x']), float(this['y']), float(this['z']))
        };
    } else if (z != null && w != null) {
        this['z'] = float(z);
        this['w'] = float(w);
        this.obj = fun() {
            return vector4(float(this['x']), float(this['y']), float(this['z']), float(this['w']))
        };
    } else {
        return error("gg.Vector has invalid arguments");
    }
    return this;
}

fun Camera2D(offset=Vector(), target=Vector(), rotation=0.0, zoom=1.0) {
    ##std:this,__camera2d
    ## `Camera2D` is an object constructor that represents the GO_OBJ for 2D Cameras
    ##
    ## offset (displacement from target)
	## target (rotation and zoom origin)
	## rotation in degrees
	## zoom (scaling), should be 1.0f by default
    ##
    ## Camera2D(offset: Vector2, target: Vector2, rotation: float, zoom: float)
    ##  -> {'offset':Vector(x,y)=Vector(),'target':Vector(x,y)=Vector(),'rotation':float=0.0,'zoom':float=1.0,'obj':|this|=>GO_OBJ[rl.Camera2D]}
    if ('obj' notin offset) {
        return error("offset must have obj() function on its map");
    }
    if ('obj' notin target) {
        return error("target must have obj() function on its map");
    }
    var this = {
        'offset': offset,
        'target': target,
        'rotation': float(rotation),
        'zoom': float(zoom),
    };
    this.obj = fun() {
        return __camera2d(this['offset']['obj'](), this['target']['obj'](), float(this['rotation']), float(this['zoom']));
    };
    return this;
}

val CameraProjection = {
    'Perspective': 0,
    'Orthographic': 1,
};

fun Camera3D(position=Vector(z=0.0), target=Vector(z=0.0), up=Vector(z=0.0), fovy=0.0, projection=CameraProjection.Perspective) {
    ##std:this,__camera3d
    ## `Camera3D` is an object constructor that represents the GO_OBJ for 2D Cameras
    ##
    ## position - cameras position
	## target - where it looks-at
	## up vector (rotation over its axis)
	## fovy - field-of-view apperture in Y (degrees) in perspective, used as near plane width in orthographic
    ## projection - Camera type, controlling projection type, either CameraProjection.Perspective or CameraProjection.Orthographic
    ##
    ## Camera3D(position: Vector3, target: Vector3, up: Vector3, fovy: float, projection: int[CameraProjection.Perspective|Orthographic])
    ##  -> {'position':Vector(x,y,z)=Vector(z=0.0),
    ##      'target':Vector(x,y,z)=Vector(z=0.0),
    ##      'up':Vector(x,y,z)=Vector(z=0.0),
    ##      'fovy':float=0.0,
    ##      'projection':int=CameraProjection.Perspective,
    ##      'obj':|this|=>GO_OBJ[rl.Camera3D]}
    if ('obj' notin position) {
        return error("position must have obj() function on its map");
    }
    if ('obj' notin target) {
        return error("target must have obj() function on its map");
    }
    if ('obj' notin up) {
        return error("up must have obj() function on its map");
    }
    var this = {
        'position': position,
        'target': target,
        'up': up,
        'fovy': float(fovy),
        'projection': int(projection),
    };
    this.obj = fun() {
        return __camera3d(this['position']['obj'](), this['target']['obj'](), this['up']['obj'](), float(this['fovy']), int(this['projection']));
    };
    return this;
}

fun Matrix(m0=0.0, m4=0.0, m8=0.0, m12=0.0, m1=0.0, m5=0.0, m9=0.0, m13=0.0, m2=0.0, m6=0.0, m10=0.0, m14=0.0, m3=0.0, m7=0.0, m11=0.0, m15=0.0) {
    ##std:this,_matrix
    ## `Matrix` returns a matrix in opengl style
    ##
    ## M0, M4, M8, M12  float
	## M1, M5, M9, M13  float
	## M2, M6, M10, M14 float
	## M3, M7, M11, M15 float
    ##
    ## If first arg is list, it will be interpreted as:
    ## [
    ##    [M0, M1, M2, M3],
    ##    [M4, M5, M6, M7],
    ##    [M8, M9, M10, M11],
    ##    [M12, M13, M14, M15],
    ## ]
    ## Note: It is still passed into the function as is seen below
    return matrix(m0, m4, m8, m12, m1, m5, m9, m13, m2, m6, m10, m14, m3, m7, m11, m15);
}

# Specialized Public Functions

fun new_window(width=800, height=600, title="gg - example app") {
    ##std:this,__init_window
    ## `new_window` will initialize the raylib window
    ##
    ## new_window(width: int=800, height: int=600, title: str="gg - example app") -> null
    __init_window(width, height, title);
    return {
        'is_ready': __is_window_ready,
        'is_fullscreen': __is_window_fullscreen,
        'is_hidden': __is_window_hidden,
        'is_maximized': __is_window_maximized,
        'is_minimized': __is_window_minimized,
        'is_focused': __is_window_focused,
        'is_resized': __is_window_resized,
        'toggle_fullscreen': __toggle_window_fullscreen,
        'maximize': __maximize_window,
        'minimize': __minimize_window,
        'restore': __restore_window,
        'close': __close_window,
        'should_close': __window_should_close,
        'set_icon': __set_window_icon,
        'set_icons': __set_window_icon,
        'set_title': __set_window_title,
        'set_position': __set_window_position,
        'set_monitor': __set_window_monitor,
        'set_min_size': __set_window_min_size,
        'set_size': __set_window_size,
        'set_opacity': __set_window_opacity,
        'set_focused': __set_window_focused
    };
}

fun clear_background(clear_color=color.white) {
    ##std:this,__clear_background
    ## `clear_background` will use the clear color to clear the background with that color
    ##
    ## clear_background(clear_color: GO_OBJ[rl.Color]=color.white) -> null
    __clear_background(clear_color)
}

fun draw_text(text, pos_x=0, pos_y=0, font_size=20, text_color=color.black) {
    ##std:this,__draw_text
    ## `draw_text` will draw the given text to the raylib window with the given parameters
    ##
    ## pos_x the x position of the text
    ## pos_y the y position of the text
    ## font_size the size of the font
    ## text_color the color of the text
    ##
    ## draw_text(text: str, pos_x: int=0, pos_y: int=0, font_size: int=20, text_color: GO_OBJ[rl.Color]=color.black) -> null
    __draw_text(text, pos_x, pos_y, font_size, text_color)
}

fun draw_texture(texture, pos_x=0, pos_y=0, tint=color.white) {
    ##std:this,__draw_texture
    ## `draw_texture` will draw the given 2D texture to the raylib window with the given parameters
    ##
    ## texture is the 2D texture, likely a file loaded with `load_texture`
    ## pos_x the x position of the texture
    ## pos_y the y position of the texture
    ## tint is the color shading to give to the texture (color.white should leave it as default)
    ##
    ## draw_texture(texture: GO_OBJ[rl.Texture2D], pos_x: int=0, pos_y: int=0, tint: GO_OBJ[rl.Color]=color.white) -> null
    __draw_texture(texture, pos_x, pos_y, tint)
}

fun draw_texture_pro(texture, source_rec=Rectangle().obj(), dest_rec=Rectangle().obj(), origin=Vector().obj(), rotation=0.0, tint=color.white) {
    ##std:this,__draw_texture
    ## `draw_texture_pro` will draw the given 2D texture to the raylib window with the given parameters defined
    ## by a rectangle with 'pro' parameters
    ##
    ## texture is the 2D texture, likely a file loaded with `load_texture`
    ## source_rec is the rectangle position of the source
    ## dest_rec is the rectangle position of the destination
    ## origin is the point where to get the texture from
    ## rotation is the amount the texture should be rotated by
    ## tint is the color shading to give to the texture (color.white should leave it as default)
    ##
    ## draw_texture_pro(texture: GO_OBJ[rl.Texture2D],
    ##                  source_rec: GO_OBJ[rl.Rectangle]=Rectangle().obj(),
    ##                  dest_rec: GO_OBJ[rl.Rectangle]=Rectangle().obj(),
    ##                  origin: GO_OBJ[rl.Vector2]=Vector().obj(),
    ##                  rotation: float=0.0, tint=color.white)
    var src_rec = if (type(source_rec) == Type.MAP && source_rec['obj'] != null) { source_rec.obj() } else { source_rec };
    var dst_rec = if (type(dest_rec) == Type.MAP && dest_rec['obj'] != null) { dest_rec.obj() } else { dest_rec };
    var org_vec2 = if (type(origin) == Type.MAP && origin['obj'] != null) { origin.obj() } else { origin };
    __draw_texture(texture, src_rec, dst_rec, org_vec2, float(rotation), tint)
}

fun begin_mode2d(cam=Camera2D()) {
    ##std:this,__begin_mode2d
    ## `begin_mode2d` will start the 2d mode for an initialized 2d camera
    ##
    ## begin_mode2d(cam: Camera2D=Camera2D()) -> null
    if ('obj' notin cam) {
        return error("cam must have obj() function on its map");
    }
    __begin_mode2d(cam.obj())
}

fun begin_mode3d(cam=Camera3D()) {
    ##std:this,__begin_mode3d
    ## `begin_mode3d` will start the 3d mode for an initialized 3d camera
    ##
    ## begin_mode3d(cam: Camera3D=Camera3D()) -> null
    if ('obj' notin cam) {
        return error("cam must have obj() function on its map");
    }
    __begin_mode3d(cam.obj())
}

fun Image(fpath_or_img=null) {
    ##std:this
    ## `Image` returns an object with functions that can operate on images
    ##
    ## Image(fpath_or_img: str|GoObj[rl.Image]=null) -> Image
    if fpath_or_img != null && type(fpath_or_img) != Type.STRING && type(fpath_or_img) != Type.GO_OBJ {
        if type(fpath_or_img) == Type.GO_OBJ && "raylib.Image" notin raw_type(fpath_or_img) {
            return error('`Image` error: fpath_or_img must be a rl.Image, got=#{raw_type(fpath_or_img)}');
        }
        return error('`Image` error: fpath_or_img must be null or string or GoObj[rl.Image]. got=#{type(fpath_or_img)}');
    }
    var this = {};
    this._img = if fpath_or_img == null { null } else if "raylib.Image" in raw_type(fpath_or_img) { fpath_or_img } else  { __load_image(fpath_or_img) };
    this.load = __load_image;
    this.is_ready = __is_image_ready;
    this.export = __image_export;
    this.copy = __image_copy;
    this.image_format = fun(new_format) {
        return __image_format(this._img, new_format);
    };
    this.to_pot = fun(fill) {
        return __image_to_pot(this._img, fill);
    };
    this.crop = fun(crop) {
        return __image_crop(this._img, crop);
    };
    this.alpha_crop = fun(threshold) {
        return __image_alpha_crop(this._img, threshold);
    };
    this.alpha_clear = fun(color, threshold) {
        return __image_alpha_clear(this._img, color, threshold);
    };
    this.alpha_mask = fun(alpha_mask) {
        return __image_alpha_mask(this._img, alpha_mask);
    };
    this.alpha_premultiply = fun() {
        return __image_alpha_premultiply(this._img);
    };
    this.blur_gaussian = fun(blur_size) {
        return __image_blur_gaussian(this._img, blur_size);
    };
    this.resize = fun(new_width, new_height) {
        return __image_resize(this._img, new_width, new_height);
    };
    this.resize_nn = fun(new_width, new_height) {
        return __image_resize_nn(this._img, new_width, new_height);
    };
    this.resize_canvas = fun(new_width, new_height, offset_x, offset_y, fill) {
        return __image_resize_canvas(this._img, new_width, new_height, offset_x, offset_y, fill);
    };
    this.mipmaps = fun() {
        return __image_mipmaps(this._img);
    };
    this.dither = fun(r_bpp, g_bpp, b_bpp, a_bpp) {
        return __image_dither(this._img, r_bpp, g_bpp, b_bpp, a_bpp);
    };
    this.flip_vertical = fun() {
        return __image_flip_vertical(this._img);
    };
    this.flip_horizontal = fun() {
        return __image_flip_horizontal(this._img);
    };
    this.rotate_cw = fun() {
        return __image_rotate_cw(this._img);
    };
    this.rotate_ccw = fun() {
        return __image_rotate_ccw(this._img);
    };
    this.color_tint = fun(color) {
        return __image_color_tint(this._img, color);
    };
    this.color_invert = fun() {
        return __image_color_invert(this._img);
    };
    this.color_grayscale = fun() {
        return __image_color_grayscale(this._img);
    };
    this.color_contrast = fun(contrast) {
        return __image_color_contrast(this._img, contrast);
    };
    this.color_brightness = fun(brightness) {
        return __image_color_brightness(this._img, brightness);
    };
    this.color_replace = fun(color, replace) {
        return __image_color_replace(this._img, color, replace);
    };
    this.load_colors = fun() {
        return __load_image_colors(this._img);
    };
    this.get_color = fun(x, y) {
        return __get_image_color(this._img, x, y);
    };
    this.draw = {
        'clear_background': fun(ds, col) {
            return __image_clear_background(this._img, ds, col)
        },
        'pixel': fun(pos_x, pos_y, col) {
            return __image_draw_pixel(this._img, pos_x, pos_y, col)
        },
        'pixel_v': fun(position, col) {
            return __image_draw_pixel_v(this._img, position, col)
        },
        'line': fun(start_pos_x, start_pos_y, end_pos_x, end_pos_y, col) {
            return __image_draw_line(this._img, start_pos_x, start_pos_y, end_pos_x, end_pos_y, col)
        },
        'line_v': fun(start, end, col) {
            return __image_draw_line_v(this._img, start, end, col)
        },
        'circle': fun(center_x, center_y, radius, col) {
            return __image_draw_circle(this._img, center_x, center_y, radius, col)
        },
        'circle_v': fun(center, radius, col) {
            return __image_draw_circle_v(this._img, center, radius, col)
        },
        'circle_lines': fun(center_x, center_y, radius, col) {
            return __image_draw_circle_lines(this._img, center_x, center_y, radius, col)
        },
        'circle_lines_v': fun(center, radius, col) {
            return __image_draw_circle_lines_v(this._img, center, radius, col)
        },
        'rectangle': fun(x, y, width, height, col) {
            return __image_draw_rectangle(this._img, x, y, width, height, col)
        },
        'rectangle_v': fun(position, size, col) {
            return __image_draw_rectangle_v(this._img, position, size, col)
        },
        'rectangle_rec': fun(rec, col) {
            return __image_draw_rectangle_rec(this._img, rec, col)
        },
        'rectangle_lines': fun(rec, thick, col) {
            return __image_draw_rectangle_lines(this._img, rec, thick, col)
        },
        'image': fun(src, src_rec, dst_rec, tint) {
            return __image_draw_image(this._img, src, src_rec, dst_rec, tint)
        },
        'text': fun(pos_x, pos_y, text, font_size, col) {
            return __image_draw_text(this._img, pos_x, pos_y, text, font_size, col)
        },
        'text_ex': fun(position, font, text, font_size, spacing, col) {
            return __image_draw_text_ex(this._img, position, font, text, font_size, spacing, col)
        },
    }
    return this;
}