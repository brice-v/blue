## `time` is the module that contains time related functions

val __now = _now;
val __sleep = _sleep;
val __parse = _parse;
val __to_str = _to_str;

fun now() {
    ## `now` returns the current unix timestamp as an int in milliseconds
    ##
    ## now() -> int
    __now()
}

fun sleep(ms) {
    ## `sleep` will pause execution of the current process for the given number of milliseconds
    ##
    ## sleep(ms: int) -> null
    __sleep(ms)
}

fun parse(date_time_str) {
    ## `parse` will parse the string as a date/time and return the unix timestamp as an int in milliseconds
    ##
    ## parse(date_time_str: str) -> int
    __parse(date_time_str)
}

fun to_str(time_as_unix_timestamp, timezone=null) {
    ## `to_str` will take the int unix timestamp in milliseconds and convert it to a human readable date/time string
    ##
    ## to_str(time_as_unix_timestamp: int, timezone: null|str=null) -> str
    __to_str(time_as_unix_timestamp, timezone)
}

val __add = _time_add;
val __format = _time_format;

fun add(ts, delta) {
    ## `add` adds milliseconds delta to timestamp (use Unit.* for days etc)
    ##
    ## add(ts: int, delta: int) -> int
    __add(ts, delta)
}

fun format(ts, layout="rfc3339", tz=null) {
    ## `format` formats timestamp with Go layout (aliases: date→2006-01-02, datetime→2006-01-02 15:04:05, iso→RFC3339)
    ##
    ## format(ts: int, layout: str="rfc3339", tz: str=null) -> str
    if (tz == null) {
        __format(ts, layout)
    } else {
        __format(ts, layout, tz)
    }
}

val timezone = {
    'Local': 'Local',
    'UTC': 'UTC',
    'GMT': 'GMT',
    'CST': 'CST',
    'EET': 'EET',
    'WET': 'WET',
    'CET': 'CET',
    'EST': 'EST',
    'MST': 'MST',
    'Cuba': 'Cuba',
    'Egypt': 'Egypt',
    'Eire': 'Eire',
    'Greenwich': 'Greenwich',
    'Iceland': 'Iceland',
    'Iran': 'Iran',
    'Israel': 'Israel',
    'Jamaica': 'Jamaica',
    'Japan': 'Japan',
    'Libya': 'Libya',
    'Poland': 'Poland',
    'Portugal': 'Portugal',
    'PRC': 'PRC',
    'Singapore': 'Singapore',
    'Turkey': 'Turkey',
    'Shanghai': 'Asia/Shanghai',
    'Chongqing': 'Asia/Chongqing',
    'Harbin': 'Asia/Harbin',
    'Urumqi': 'Asia/Urumqi',
    'HongKong': 'Asia/Hong_Kong',
    'Macao': 'Asia/Macao',
    'Taipei': 'Asia/Taipei',
    'Tokyo': 'Asia/Tokyo',
    'Saigon': 'Asia/Saigon',
    'Seoul': 'Asia/Seoul',
    'Bangkok': 'Asia/Bangkok',
    'Dubai': 'Asia/Dubai',
    'NewYork': 'America/New_York',
    'LosAngeles': 'America/Los_Angeles',
    'Chicago': 'America/Chicago',
    'Moscow': 'Europe/Moscow',
    'London': 'Europe/London',
    'Berlin': 'Europe/Berlin',
    'Paris': 'Europe/Paris',
    'Rome': 'Europe/Rome',
    'Sydney': 'Australia/Sydney',
    'Melbourne': 'Australia/Melbourne',
    'Darwin': 'Australia/Darwin',
}

# These units are all in milliseconds so they can be added/subtracted to/from a timestamp and parsed appropriately
val Unit = {
    MILLISECOND: 1,
    SECOND: 1 * 1000,
    MINUTE: 1 * 1000 * 60,
    HOUR: 1 * 1000 * 60 * 60,
    DAY: 1 * 1000 * 60 * 60 * 24,
};