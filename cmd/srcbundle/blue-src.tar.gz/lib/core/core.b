val Type = {
    BOOL: 'BOOLEAN',
    INT: 'INTEGER',
    UINT: 'UINTEGER',
    FLOAT: 'FLOAT',
    BIGINT: 'BIG_INTEGER',
    BIGFLOAT: 'BIG_FLOAT',
    BYTES: 'BYTES',
    STRING: 'STRING',
    SET: 'SET',
    MAP: 'MAP',
    LIST: 'LIST',
    FUN: 'FUNCTION',
    CLOSURE: 'CLOSURE',
    BUILTIN: 'BUILTIN',
    MODULE: 'MODULE_OBJ',
    GO_OBJ: 'GO_OBJ',
    REGEX: 'REGEX',
    NULL: 'NULL',
    PROCESS: 'PROCESS',
    STRUCT: 'BLUE_STRUCT_OBJ',
    ERR: 'ERROR',
};

val __fetch = _fetch;
fun fetch(resource, options=null, full_resp=true) {
    ##core:this,__fetch
    ## `fetch` allows the user to send GET, POST, PUT, PATCH, and DELETE
    ## http methods to a various resource
    ##
    ## there are other specific methods that populate these
    ## options appropriately. user-agent in header is always
    ## set to one specific to blue.
    ##
    ## example option to send get request:
    ##                 {method: 'GET', headers: {}, body: null}
    ##
    ## example option to send post request:
    ## {method: 'POST', body: str, headers: {'content-type': mime_type}}
    ##
    ## fetch(resource: str, options: map[any:str]=null, full_resp: bool=true) -> any
    if (options == null) {
        options = {
            method: 'GET',
            headers: {},
            body: null,
        };
    } else {
        val t = options.type();
        if (t != 'MAP') {
            return error("`fetch` error:  options must be MAP. got=#{t}");
        }
        if (options.method == null) {
            options.method = 'GET';
        }
        if (options.headers == null) {
            options.headers = {};
        } else {
            val ht = type(options.headers);
            if (ht != 'MAP') {
                return error("`fetch` error:  options.headers must be MAP. got=#{ht}");
            }
        }
        if (options.method == 'GET' or options.method == 'DELETE') {
            if (options.body != null) {
                return error("`fetch` error: options.body must be NULL for 'GET' or 'DELETE' methods");
            }
        }
    }
    __fetch(resource, options.method, options.headers, options.body, full_resp)
}

fun send(obj, value) {
    ##core:ignore
    match obj {
        {t: "ws", v: _} => {
            from http import {ws_send}
            ws_send(obj.v, value)
        },
        {t: "ws/client", v: _} => {
            from http import {ws_client_send}
            ws_client_send(obj.v, value)
        },
        _ => {
            error("obj `#{obj}` is invalid type. got=`#{obj}` (#{type(obj)})")
        },
    }
}

fun recv(obj) {
    ##core:ignore
    match obj {
        {t: "ws", v: _} => {
            from http import {ws_recv}
            ws_recv(obj.v)
        },
        {t: "ws/client", v: _} => {
            from http import {ws_client_recv}
            ws_client_recv(obj.v)
        },
        {t: "sub", v: _} => {
            _pubsub_sub_listen(obj.v)
        },
        _ => {
            error("obj `#{obj}` is invalid type. got=`#{obj}` (#{type(obj)})")
        },
    }
}

fun read(obj, as_bytes=false) {
    ##core:ignore
    match obj {
        {t: _, v: _} => {
            if ("net" in obj.t) {
                from net import {net_read}
                net_read(obj.v, obj.t)
            }
        },
        _ => {
            _read(obj, as_bytes)
        },
    }
}

fun write(obj, value) {
    ##core:ignore
    match obj {
        {t: _, v: _} => {
            if ("net" in obj.t) {
                from net import {net_write}
                net_write(obj.v, obj.t, value)
            }
        },
        _ => {
            _write(obj, value)
        },
    }
}

fun reduce(list, f, acc=null) {
    ##core:ignore
    for (e in list) {
        acc = f(acc,e)
    }
    return acc;
}

val __sort = _sort;
val __sorted = _sorted;
fun sort(list, reverse=false, key=null) {
    ##core:__sort
    return _sort(list, reverse, key);
}

fun sorted(list, reverse=false, key=null) {
    ##core:__sorted
    return _sorted(list, reverse, key);
}

fun find_all(str_to_search, query, method="regex") {
    ##core:ignore
    from search import {by_regex, by_xpath}
    if type(query) == Type.REGEX {
        method = 'regex';
    }
    match method {
        "regex" => {
            by_regex(str_to_search, query, false)
        },
        "xpath" => {
            by_xpath(str_to_search, query, false)
        },
        _ => {
            error("`find_all` unsupported method '#{method}'")
        },
    }
}

fun find_one(str_to_search, query, method="regex") {
    ##core:ignore
    from search import {by_regex, by_xpath}
    if type(query) == Type.REGEX {
        method = 'regex';
    }
    match method {
        "regex" => {
            by_regex(str_to_search, query, true)
        },
        "xpath" => {
            by_xpath(str_to_search, query, true)
        },
        _ => {
            error("`find_one` unsupported method '#{method}'")
        },
    }
}

fun close(obj) {
    ##core:ignore
    match obj {
        {t: _, v: _} => {
            if ("net" in obj.t) {
                from net import {net_close}
                net_close(obj.v, obj.t)
            }
        },
        _ => {
            error("obj `#{obj}` is invalid type. got=`#{obj}` (#{type(obj)})")
        },
    }
}

fun accept(obj) {
    ##core:ignore
    match obj {
        {t: "net/tcp", v: _} => {
            from net import {net_accept}
            net_accept(obj.v)
        },
        _ => {
            error("obj `#{obj}` is invalid type. got=`#{obj}` (#{type(obj)})")
        },
    }
}

val __substr = _substr;
fun substr(s, start=0, end=-1) {
    ##core:__substr
    __substr(s, start, end)
}

val __center = _center;
fun center(s, length, pad=" ") {
    ##core:__center
    __center(s, length, pad)
}

val __ljust = _ljust;
fun ljust(s, length, pad=" ") {
    ##core:__ljust
    __ljust(s, length, pad)
}

val __rjust = _rjust;
fun rjust(s, length, pad=" ") {
    ##core:__rjust
    __rjust(s, length, pad)
}

val __to_bytes = _to_bytes;
fun to_bytes(str_to_convert, is_hex=false) {
    ##core:this,__to_bytes
    ## `to_bytes` will convert the given string to the bytes representation
    ## this is useful to get the binary version of the string to use in various
    ## functions
    ##
    ## is_hex is set to false by default assuming the string is not already in bytes format
    ## if the str_to_convert is in hexadecimal crypto.decode is imported and used
    ##
    ## to_bytes(str_to_convert: str, is_hex: bool=false) -> bytes
    if (is_hex) {
        from crypto import {decode}
        return decode(str_to_convert, as_bytes=true);
    } else {
        return __to_bytes(str_to_convert);
    }
}

val __replace = _replace;
val __replace_regex = _replace_regex;
fun replace(str_to_replace, replacer, replaced, is_regex=false) {
    ##core:this,__replace,__replace_regex
    ## `replace` will take the string, and replace the replacer with replaced
    ##
    ## replacer can be a string or regex
    ## replaced should be a string
    ##
    ## is_regex can be used to convert a replacer string to a regex object
    ##
    ## replace(str_to_replace: str, replacer: str|regex, replaced: str, is_regex: bool=false) -> str
    if type(replacer) == Type.REGEX {
        is_regex = true;
    }
    if is_regex {
        return __replace_regex(str_to_replace, replacer, replaced);
    } else {
        return __replace(str_to_replace, replacer, replaced);
    }
}

val KV = {
    put: _kv_put,
    get: _kv_get,
    delete: _kv_delete,
}

val pubsub = {
    subscribe: _subscribe,
    publish: _publish,
    broadcast: _broadcast,
    get_subscriber_count: _get_subscriber_count,
};

val uuid = {
    'new': _new_uuid,
}

val path = {
    'join': _path_join,
    'clean': _path_clean,
    'dir': _path_dir,
    'base': _path_base,
    'ext': _path_ext,
    'is_abs': _path_is_abs,
    'rel': _path_rel,
    'abs': _abs_path,
}


fun __go_metrics(flat=false) {
    ##core:ignore
    # flat implies that we just want each metric path as its own key
    var __metrics = _go_metrics();
    var __metrics_split_nl = __metrics.split("\n");
    __metrics_split_nl = [x for (x in __metrics_split_nl) if (x != '')];

    var __total_metrics = {};
    if (flat) {
        for (metric in __metrics_split_nl) {
            val metric_path_and_value = metric.split(": ");
            val path = metric_path_and_value[0];
            val metric_value = to_num(metric_path_and_value[1]);
            __total_metrics[path] = metric_value;
        }
        return __total_metrics;
    }

    val __set_value_from_list_of_keys_in_map = fun(m, l, value) {
        # m is our map
        # l is our list of string keys (the last key there is a key to a value)
        # value is what were trying to set
        
        # this is our starting point
        var current_map = m;
        var i = 0;
        for (true) {
            var starting_key = l[i];
            if (starting_key in current_map) {
                current_map = current_map[starting_key];
            } else {
                if (i == len(l) - 1) {
                    current_map[starting_key] = value;
                    break;
                }
                current_map[starting_key] = {};
                current_map = current_map[starting_key];
            }
            i += 1;
        }
    }

    for (metric in __metrics_split_nl) {
        val metric_path_and_value = metric.split(": ");
        val path = metric_path_and_value[0];
        val metric_value = to_num(metric_path_and_value[1]);
        var metric_path_list = path.split("/");
        metric_path_list = [x for (x in metric_path_list) if (x != '')];
        __set_value_from_list_of_keys_in_map(__total_metrics, metric_path_list, metric_value);
    }

    return __total_metrics;
}

val runtime = {
    go_metrics: __go_metrics,
    gc: _gc,
    os: get_os(),
    arch: get_arch(),
    version: _version(),
    stats: {
        num_cpu: _num_cpu,
        num_process: _num_process, 
        num_max_cpu: _num_max_cpu,
        num_os_thread: _num_os_thread,
        mem: _get_mem_stats,
    },
    set_max_cpu: _set_max_cpu,
    debug: {
        get_stack_trace: _get_stack_trace,
        print_stack_trace: _print_stack_trace,
        set_gc_percent: _set_gc_percent,
        set_max_stack: _set_max_stack,
        set_max_threads: _set_max_threads,
        set_mem_limit: _set_mem_limit,
    },
};
